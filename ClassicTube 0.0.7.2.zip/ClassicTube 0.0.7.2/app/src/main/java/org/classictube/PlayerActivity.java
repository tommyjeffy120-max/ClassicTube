package org.classictube;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONObject;
import android.widget.Toast;

/** In-app player built from platform APIs available on Android 1.5+ (including API 8). */
public class PlayerActivity extends Activity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_VIDEO_ID = "video_id";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_MIME = "mime";
    public static final String EXTRA_LABEL = "label";
    public static final String EXTRA_URLS = "urls";
    public static final String EXTRA_LABELS = "labels";
    public static final String EXTRA_MIMES = "mimes";
    public static final String EXTRA_PROVIDER_NAMES = "provider_names";
    public static final String EXTRA_PROVIDER_BASES = "provider_bases";
    public static final String EXTRA_START_INDEX = "start_index";
    public static final String EXTRA_RELATED_PROVIDER_NAME = "related_provider_name";
    public static final String EXTRA_RELATED_PROVIDER_BASE = "related_provider_base";
    public static final String EXTRA_RELATED_SOURCES = "related_sources";

    private LinearLayout rootLayout;
    private LinearLayout headerLayout;
    private LinearLayout buttonsLayout;
    private Button fullscreenButton;
    private FrameLayout videoFrame;
    private TextView relatedHeading;
    private TextView relatedStatus;
    private ScrollView relatedScroll;
    private LinearLayout relatedContainer;
    private int normalVideoFrameHeight;
    private boolean fullscreen;
    private int originalRequestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

    private VideoView videoView;
    private ProgressBar spinner;
    private TextView status;
    private TextView titleView;
    private TextView sourceView;
    private String title;
    private String videoId;
    private String[] urls;
    private String[] labels;
    private String[] mimes;
    private String[] providerNames;
    private String[] providerBases;
    private int streamIndex;
    private final Handler playbackHandler = new Handler();
    private Runnable playbackTimeoutRunnable;
    private final HashSet<String> failedUrls = new HashSet<String>();
    private String currentUrl;
    private String currentMime;
    private String currentLabel;
    private String relatedProviderName;
    private String relatedProviderBase;
    private ArrayList<String> relatedSources;
    private List<VideoItem> relatedItems = new ArrayList<VideoItem>();
    private boolean loadingRelated;
    private boolean prepared;
    private boolean wasPlaying;
    private int savedPosition;
    private MediaController controller;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        originalRequestedOrientation = getRequestedOrientation();
        title = getIntent().getStringExtra(EXTRA_TITLE);
        videoId = getIntent().getStringExtra(EXTRA_VIDEO_ID);
        urls = getIntent().getStringArrayExtra(EXTRA_URLS);
        labels = getIntent().getStringArrayExtra(EXTRA_LABELS);
        mimes = getIntent().getStringArrayExtra(EXTRA_MIMES);
        providerNames = getIntent().getStringArrayExtra(EXTRA_PROVIDER_NAMES);
        providerBases = getIntent().getStringArrayExtra(EXTRA_PROVIDER_BASES);
        streamIndex = getIntent().getIntExtra(EXTRA_START_INDEX, 0);
        currentUrl = getIntent().getStringExtra(EXTRA_URL);
        currentMime = getIntent().getStringExtra(EXTRA_MIME);
        currentLabel = getIntent().getStringExtra(EXTRA_LABEL);
        relatedProviderName = getIntent().getStringExtra(EXTRA_RELATED_PROVIDER_NAME);
        relatedProviderBase = getIntent().getStringExtra(EXTRA_RELATED_PROVIDER_BASE);
        activateProviderForIndex(streamIndex);
        relatedSources = getIntent().getStringArrayListExtra(EXTRA_RELATED_SOURCES);
        if (relatedSources == null) relatedSources = new ArrayList<String>();
        if (title == null) title = "ClassicTube Player";
        if (currentMime == null || currentMime.length() == 0) currentMime = "video/*";
        if (currentLabel == null) currentLabel = "Video stream";
        if (currentUrl == null || currentUrl.length() == 0) {
            Toast.makeText(this, "No video URL was supplied.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildPlayerUi();
        startStream(currentUrl, currentMime, currentLabel, 0);
        loadRelatedVideos();
    }

    private void buildPlayerUi() {
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.rgb(15, 15, 15));

        headerLayout = new LinearLayout(this);
        headerLayout.setOrientation(LinearLayout.VERTICAL);
        headerLayout.setPadding(dp(12), dp(9), dp(12), dp(8));
        headerLayout.setBackgroundColor(Color.rgb(190, 25, 35));
        titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(17);
        headerLayout.addView(titleView, new LinearLayout.LayoutParams(-1, -2));
        sourceView = new TextView(this);
        sourceView.setTextColor(Color.rgb(255, 230, 230));
        sourceView.setTextSize(12);
        sourceView.setText(currentLabel);
        headerLayout.addView(sourceView, new LinearLayout.LayoutParams(-1, -2));
        rootLayout.addView(headerLayout, new LinearLayout.LayoutParams(-1, -2));

        int screenWidth = getWindowManager().getDefaultDisplay().getWidth();
        normalVideoFrameHeight = Math.max(dp(160), (screenWidth * 9) / 16);
        videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        videoView = new VideoView(this);
        videoFrame.addView(videoView, new FrameLayout.LayoutParams(-1, -1));
        spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        FrameLayout.LayoutParams spinParams = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        videoFrame.addView(spinner, spinParams);
        rootLayout.addView(videoFrame, new LinearLayout.LayoutParams(-1, normalVideoFrameHeight));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(dp(10), dp(7), dp(10), dp(7));
        status.setText("Connecting to stream...");
        rootLayout.addView(status, new LinearLayout.LayoutParams(-1, -2));

        buttonsLayout = new LinearLayout(this);
        buttonsLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonsLayout.setPadding(dp(4), dp(3), dp(4), dp(7));
        Button retry = new Button(this);
        retry.setText("Retry");
        buttonsLayout.addView(retry, new LinearLayout.LayoutParams(0, -2, 1));
        Button next = new Button(this);
        next.setText("Next source");
        next.setTextSize(12);
        next.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(next, new LinearLayout.LayoutParams(0, -2, 1));
        Button external = new Button(this);
        external.setText("External");
        external.setTextSize(12);
        external.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(external, new LinearLayout.LayoutParams(0, -2, 1));
        fullscreenButton = new Button(this);
        fullscreenButton.setText("Fullscreen");
        fullscreenButton.setTextSize(12);
        fullscreenButton.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(fullscreenButton, new LinearLayout.LayoutParams(0, -2, 1));
        rootLayout.addView(buttonsLayout, new LinearLayout.LayoutParams(-1, -2));

        relatedHeading = new TextView(this);
        relatedHeading.setText("Related videos");
        relatedHeading.setTextColor(Color.WHITE);
        relatedHeading.setTextSize(15);
        relatedHeading.setPadding(dp(10), dp(8), dp(10), dp(8));
        relatedHeading.setBackgroundColor(Color.rgb(38, 38, 38));
        rootLayout.addView(relatedHeading, new LinearLayout.LayoutParams(-1, -2));

        relatedStatus = new TextView(this);
        relatedStatus.setText("Finding recommendations...");
        relatedStatus.setTextColor(Color.LTGRAY);
        relatedStatus.setTextSize(12);
        relatedStatus.setPadding(dp(10), dp(6), dp(10), dp(6));
        relatedStatus.setBackgroundColor(Color.rgb(25, 25, 25));
        rootLayout.addView(relatedStatus, new LinearLayout.LayoutParams(-1, -2));

        relatedScroll = new ScrollView(this);
        relatedScroll.setFillViewport(false);
        relatedScroll.setBackgroundColor(Color.rgb(244, 244, 244));
        relatedContainer = new LinearLayout(this);
        relatedContainer.setOrientation(LinearLayout.VERTICAL);
        relatedScroll.addView(relatedContainer, new ScrollView.LayoutParams(-1, -2));
        rootLayout.addView(relatedScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(rootLayout);

        controller = new MediaController(this);
        videoView.setMediaController(controller);
        controller.setAnchorView(videoView);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                cancelPlaybackTimeout();
                prepared = true;
                spinner.setVisibility(View.GONE);
                rememberSuccessfulPlaybackSource();
                status.setText("Playing in ClassicTube. Tap the video for controls.");
                controller.setAnchorView(videoView);
                if (savedPosition > 0) {
                    try { videoView.seekTo(savedPosition); } catch (Exception ignored) {}
                    savedPosition = 0;
                }
                videoView.start();
                wasPlaying = true;
            }
        });
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                cancelPlaybackTimeout();
                spinner.setVisibility(View.GONE);
                status.setText("Playback finished.");
                wasPlaying = false;
            }
        });
        videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                cancelPlaybackTimeout();
                prepared = false;
                wasPlaying = false;
                String failed = currentUrl;
                if (failed != null) failedUrls.add(failed);
                advanceAfterFailure("Playback failed (" + what + "/" + extra + "). Trying the next source automatically...");
                return true;
            }
        });
        retry.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                failedUrls.clear();
                startStream(currentUrl, currentMime, currentLabel, 0);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { playNextSource(); }
        });
        external.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openExternal(); }
        });
        fullscreenButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setFullscreen(true); }
        });
    }

    /** Hide the app chrome and status bar, while keeping Android's navigation bar visible. */
    private void setFullscreen(boolean enabled) {
        if (fullscreen == enabled || rootLayout == null) return;
        fullscreen = enabled;
        if (enabled) {
            headerLayout.setVisibility(View.GONE);
            status.setVisibility(View.GONE);
            buttonsLayout.setVisibility(View.GONE);
            relatedHeading.setVisibility(View.GONE);
            relatedStatus.setVisibility(View.GONE);
            relatedScroll.setVisibility(View.GONE);
            if (videoFrame != null) {
                videoFrame.getLayoutParams().height = -1;
                videoFrame.requestLayout();
            }
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            // Landscape gives the video more room. The system navigation bar stays visible,
            // so the user can press Back once to return to the normal player layout.
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            Toast.makeText(this, "Fullscreen enabled. Press Back to exit.", Toast.LENGTH_SHORT).show();
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            setRequestedOrientation(originalRequestedOrientation);
            headerLayout.setVisibility(View.VISIBLE);
            status.setVisibility(View.VISIBLE);
            buttonsLayout.setVisibility(View.VISIBLE);
            relatedHeading.setVisibility(View.VISIBLE);
            relatedStatus.setVisibility(View.VISIBLE);
            relatedScroll.setVisibility(View.VISIBLE);
            if (videoFrame != null) {
                videoFrame.getLayoutParams().height = normalVideoFrameHeight;
                videoFrame.requestLayout();
            }
        }
    }

    @Override public void onBackPressed() {
        if (fullscreen) {
            setFullscreen(false);
            return;
        }
        super.onBackPressed();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    private void loadRelatedVideos() {
        if (loadingRelated || videoId == null || videoId.length() == 0) return;
        loadingRelated = true;
        final String requestedVideoId = videoId;
        final ArrayList<VideoItem> cachedInitially = readRelatedCache(requestedVideoId);
        final boolean hadCached = cachedInitially != null && !cachedInitially.isEmpty();
        if (hadCached) {
            relatedItems = cachedInitially;
            renderRelatedVideos(cachedInitially);
            relatedStatus.setText("Showing saved related videos while checking live providers...");
        } else {
            relatedStatus.setText("Finding recommendations from compatible providers...");
        }

        new Thread(new Runnable() {
            public void run() {
                final ArrayList<VideoItem> found = new ArrayList<VideoItem>();
                final ArrayList<String> attempted = new ArrayList<String>();
                int invidiousTried = 0;
                int pipedTried = 0;

                // Only Invidious and Piped currently expose recommendation APIs in this client.
                if (isRelatedProvider(relatedProviderName) && relatedProviderBase != null && relatedProviderBase.length() > 0) {
                    String key = relatedProviderName + "|" + relatedProviderBase;
                    attempted.add(key);
                    if ("Invidious".equals(relatedProviderName)) invidiousTried++;
                    else if ("Piped".equals(relatedProviderName)) pipedTried++;
                    try {
                        List<VideoItem> response = fetchRelated(relatedProviderName, relatedProviderBase, requestedVideoId);
                        if (response != null && !response.isEmpty()) rememberGoodRelatedSource(relatedProviderName, relatedProviderBase);
                        mergeRelated(found, response, requestedVideoId);
                    } catch (Exception ignored) {}
                }

                // Try the last working recommendations host first, then the other discovered
                // instances. Rotating to a known-good host avoids always starting at stale defaults.
                ArrayList<String> orderedRelatedSources = new ArrayList<String>();
                String lastGood = getSharedPreferences("classictube", MODE_PRIVATE).getString("last_good_related_source", "");
                if (lastGood.indexOf('|') > 0) orderedRelatedSources.add(lastGood);
                for (String source : relatedSources) if (source != null && source.indexOf('|') > 0 && !orderedRelatedSources.contains(source)) orderedRelatedSources.add(source);

                // Try up to three distinct instances per API type. Public instance lists can
                // contain stale entries; trying only one or two made recommendations brittle.
                for (int i = 0; i < orderedRelatedSources.size() && found.size() < 6; i++) {
                    String encoded = orderedRelatedSources.get(i);
                    int split = encoded.indexOf('|');
                    if (split <= 0 || split >= encoded.length() - 1) continue;
                    String name = encoded.substring(0, split);
                    String base = encoded.substring(split + 1);
                    if (!isRelatedProvider(name)) continue;
                    if ("Invidious".equals(name) && invidiousTried >= 3) continue;
                    if ("Piped".equals(name) && pipedTried >= 3) continue;
                    String key = name + "|" + base;
                    if (attempted.contains(key)) continue;
                    attempted.add(key);
                    if ("Invidious".equals(name)) invidiousTried++;
                    else if ("Piped".equals(name)) pipedTried++;
                    try {
                        List<VideoItem> response = fetchRelated(name, base, requestedVideoId);
                        if (response != null && !response.isEmpty()) rememberGoodRelatedSource(name, base);
                        mergeRelated(found, response, requestedVideoId);
                    } catch (Exception ignored) {}
                }

                // If a backend is alive but its recommendation endpoint is missing or empty,
                // use a bounded title search as a fallback. Search results are suggestions,
                // not claimed to be the platform's official recommendations.
                boolean usedSearchFallback = false;
                if (found.isEmpty()) {
                    String query = recommendationQuery(title);
                    int searches = 0;
                    for (int i = 0; i < attempted.size() && found.size() < 6 && searches < 2; i++) {
                        String encoded = attempted.get(i);
                        int split = encoded.indexOf('|');
                        if (split <= 0 || split >= encoded.length() - 1) continue;
                        String name = encoded.substring(0, split);
                        String base = encoded.substring(split + 1);
                        if (!isRelatedProvider(name)) continue;
                        searches++;
                        try {
                            List<VideoItem> matches = "Invidious".equals(name)
                                ? new InvidiousProvider(base).search(query)
                                : new PipedProvider(base).search(query);
                            int before = found.size();
                            mergeRelated(found, matches, requestedVideoId);
                            if (found.size() > before) usedSearchFallback = true;
                        } catch (Exception ignored) {}
                    }
                }

                final ArrayList<VideoItem> result = found;
                final int providersTried = attempted.size();
                final boolean searchFallbackUsed = usedSearchFallback;
                runOnUiThread(new Runnable() {
                    public void run() {
                        loadingRelated = false;
                        if (videoId == null || !videoId.equals(requestedVideoId)) {
                            loadRelatedVideos();
                            return;
                        }
                        if (result.size() > 0) {
                            relatedItems = result;
                            saveRelatedCache(requestedVideoId, result);
                            renderRelatedVideos(result);
                            if (searchFallbackUsed) {
                                relatedStatus.setText("Related search suggestions · " + result.size() + " found");
                            }
                        } else if (hadCached) {
                            // Keep usable stale data on screen when all current APIs are down.
                            relatedItems = cachedInitially;
                            relatedStatus.setText("Showing saved related videos. Live providers did not return an update.");
                        } else {
                            relatedItems = new ArrayList<VideoItem>();
                            relatedStatus.setText("No recommendations available right now. Checked " + providersTried +
                                " provider(s); servers may be offline or may not support recommendations.");
                            relatedContainer.removeAllViews();
                        }
                    }
                });
            }
        }, "ClassicTube-related").start();
    }

    private String recommendationQuery(String videoTitle) {
        String query = videoTitle == null ? "" : videoTitle.trim();
        // Keep requests short and avoid sending an empty query to public instances.
        while (query.length() > 0 && (query.charAt(0) == '-' || query.charAt(0) == '|')) query = query.substring(1).trim();
        if (query.length() > 100) query = query.substring(0, 100).trim();
        return query.length() < 2 ? "popular music videos" : query;
    }

    private ArrayList<VideoItem> readRelatedCache(String id) {
        ArrayList<VideoItem> out = new ArrayList<VideoItem>();
        try {
            String raw = getSharedPreferences("classictube_related_cache", MODE_PRIVATE).getString("video_" + id, "");
            if (raw == null || raw.length() == 0) return out;
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length() && out.size() < 6; i++) {
                JSONObject object = array.optJSONObject(i);
                if (object == null) continue;
                String itemId = object.optString("id", "");
                if (!itemId.matches("[A-Za-z0-9_-]{6,20}") || id.equals(itemId)) continue;
                VideoItem item = new VideoItem();
                item.id = itemId;
                item.title = object.optString("title", "Untitled video");
                item.author = object.optString("author", "");
                item.duration = object.optString("duration", "");
                item.thumbnail = object.optString("thumbnail", "");
                item.provider = object.optString("provider", "");
                boolean duplicate = false;
                for (VideoItem old : out) if (old.id.equals(item.id)) duplicate = true;
                if (!duplicate) out.add(item);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void saveRelatedCache(String id, List<VideoItem> items) {
        if (id == null || items == null || items.isEmpty()) return;
        try {
            JSONArray array = new JSONArray();
            for (int i = 0; i < items.size() && i < 6; i++) {
                VideoItem item = items.get(i);
                if (item == null || item.id == null || item.id.length() == 0 || id.equals(item.id)) continue;
                JSONObject object = new JSONObject();
                object.put("id", item.id);
                object.put("title", item.title == null ? "" : item.title);
                object.put("author", item.author == null ? "" : item.author);
                object.put("duration", item.duration == null ? "" : item.duration);
                object.put("thumbnail", item.thumbnail == null ? "" : item.thumbnail);
                object.put("provider", item.provider == null ? "" : item.provider);
                array.put(object);
            }
            getSharedPreferences("classictube_related_cache", MODE_PRIVATE).edit()
                .putString("video_" + id, array.toString()).commit();
        } catch (Exception ignored) {}
    }

    private void rememberGoodRelatedSource(String name, String base) {
        if (!isRelatedProvider(name) || base == null || base.length() == 0) return;
        getSharedPreferences("classictube", MODE_PRIVATE).edit()
            .putString("last_good_related_source", name + "|" + base).commit();
    }

    private boolean isRelatedProvider(String name) {
        return "Invidious".equals(name) || "Piped".equals(name);
    }

    private List<VideoItem> fetchRelated(String name, String base, String requestedVideoId) throws Exception {
        if ("Invidious".equals(name)) return new InvidiousProvider(base).relatedVideos(requestedVideoId);
        if ("Piped".equals(name)) return new PipedProvider(base).relatedVideos(requestedVideoId);
        return new ArrayList<VideoItem>();
    }

    private void mergeRelated(List<VideoItem> target, List<VideoItem> additions, String currentId) {
        if (additions == null) return;
        for (VideoItem item : additions) {
            if (item == null || item.id == null || item.id.length() == 0 || currentId.equals(item.id)) continue;
            boolean duplicate = false;
            for (VideoItem existing : target) if (existing.id.equals(item.id)) { duplicate = true; break; }
            if (!duplicate) target.add(item);
            if (target.size() >= 6) break;
        }
    }

    private void renderRelatedVideos(List<VideoItem> items) {
        relatedContainer.removeAllViews();
        if (items == null || items.size() == 0) {
            relatedStatus.setText("No recommendations are available from the compatible providers.");
            return;
        }
        relatedStatus.setText(items.size() == 6 ? "6 recommendations" : (items.size() + " recommendations found"));
        for (int i = 0; i < items.size() && i < 6; i++) {
            final VideoItem item = items.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(7), dp(6), dp(7), dp(6));
            row.setBackgroundColor(Color.rgb(244, 244, 244));
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(Color.rgb(210, 210, 210));
            image.setTag("related:" + item.id);
            row.addView(image, new LinearLayout.LayoutParams(dp(112), dp(68)));
            LinearLayout textColumn = new LinearLayout(this);
            textColumn.setOrientation(LinearLayout.VERTICAL);
            textColumn.setPadding(dp(9), dp(1), dp(2), dp(1));
            row.addView(textColumn, new LinearLayout.LayoutParams(0, -2, 1));
            TextView itemTitle = new TextView(this);
            itemTitle.setText(item.title == null || item.title.length() == 0 ? "Untitled video" : item.title);
            itemTitle.setTextColor(Color.BLACK);
            itemTitle.setTextSize(14);
            textColumn.addView(itemTitle, new LinearLayout.LayoutParams(-1, -2));
            TextView meta = new TextView(this);
            meta.setTextColor(Color.DKGRAY);
            meta.setTextSize(11);
            String detail = item.author == null ? "" : item.author;
            if (item.duration != null && item.duration.length() > 0) detail += (detail.length() > 0 ? " · " : "") + item.duration;
            meta.setText(detail);
            textColumn.addView(meta, new LinearLayout.LayoutParams(-1, -2));
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { playRelatedVideo(item); }
            });
            relatedContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));
            View line = new View(this);
            line.setBackgroundColor(Color.rgb(205, 205, 205));
            relatedContainer.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            loadRelatedThumbnail(image, item);
        }
    }

    private void loadRelatedThumbnail(final ImageView target, final VideoItem item) {
        final String expectedTag = "related:" + item.id;
        new Thread(new Runnable() {
            public void run() {
                Bitmap bitmap = null;
                String[] candidates = new String[] {item.thumbnail,
                    "https://i.ytimg.com/vi/" + item.id + "/mqdefault.jpg",
                    "https://img.youtube.com/vi/" + item.id + "/hqdefault.jpg"};
                for (int i = 0; i < candidates.length && bitmap == null; i++) {
                    String address = candidates[i];
                    if (!HttpJson.isHttpUrl(address)) continue;
                    boolean duplicate = false;
                    for (int j = 0; j < i; j++) if (address.equals(candidates[j])) duplicate = true;
                    if (duplicate) continue;
                    HttpURLConnection connection = null;
                    InputStream input = null;
                    try {
                        connection = (HttpURLConnection) new URL(address).openConnection();
                        connection.setConnectTimeout(2200);
                        connection.setReadTimeout(2800);
                        connection.setInstanceFollowRedirects(true);
                        connection.setRequestProperty("User-Agent", "ClassicTube/0.6 (Android video client)");
                        int code = connection.getResponseCode();
                        if (code < 200 || code >= 300) continue;
                        input = connection.getInputStream();
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inSampleSize = 2;
                        bitmap = BitmapFactory.decodeStream(input, null, options);
                    } catch (Exception ignored) {
                    } finally {
                        try { if (input != null) input.close(); } catch (Exception ignored) {}
                        if (connection != null) connection.disconnect();
                    }
                }
                final Bitmap result = bitmap;
                if (result != null) runOnUiThread(new Runnable() {
                    public void run() {
                        if (expectedTag.equals(target.getTag())) target.setImageBitmap(result);
                        else result.recycle();
                    }
                });
            }
        }, "ClassicTube-related-thumb").start();
    }

    private static int playbackPriority(String providerName) {
        if ("yt2009".equals(providerName)) return 0;
        if ("YtAPILegacy".equals(providerName)) return 1;
        if ("Invidious".equals(providerName)) return 2;
        if ("Piped".equals(providerName)) return 3;
        return 9;
    }

    private String displaySourceLabel(String name, String base, String qualityLabel) {
        String host = base == null ? "" : base;
        try { host = new URL(base).getHost(); } catch (Exception ignored) {}
        String quality = qualityLabel == null ? "Available stream" : qualityLabel.trim();
        String suffix = " · " + name;
        if (quality.toLowerCase(java.util.Locale.US).endsWith(suffix.toLowerCase(java.util.Locale.US))) {
            quality = quality.substring(0, quality.length() - suffix.length()).trim();
        }
        return name + (host.length() == 0 ? "" : " [" + host + "]") + " · " + quality;
    }

    private Provider makeProvider(String name, String base) {
        if ("Invidious".equals(name)) return new InvidiousProvider(base);
        if ("Piped".equals(name)) return new PipedProvider(base);
        if ("YtAPILegacy".equals(name)) return new YtApiLegacyProvider(base);
        if ("yt2009".equals(name)) return new Yt2009Provider(base);
        return null;
    }

    private void playRelatedVideo(final VideoItem item) {
        if (item == null || item.id == null || item.id.length() == 0) return;
        status.setText("Finding a stream for related video...");
        spinner.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<StreamItem> choices = new ArrayList<StreamItem>();
                int attempted = 0;
                ArrayList<String> orderedSources = new ArrayList<String>();
                SharedPreferences prefs = getSharedPreferences("classictube", MODE_PRIVATE);

                // Critical: include the very yt2009 instance playing the current video even
                // when the asynchronous instance registry failed and relatedSources is stale.
                if ("yt2009".equals(relatedProviderName)) {
                    addPlaybackSource(orderedSources, relatedProviderName, relatedProviderBase);
                }
                addPlaybackSource(orderedSources, "yt2009", prefs.getString("preferred_yt2009", ""));
                addPlaybackSource(orderedSources, "yt2009", prefs.getString("last_good_yt2009", ""));

                // Include every discovered yt2009 base first. The currently playing host and
                // remembered hosts are deliberately not dependent on registry discovery.
                for (String source : relatedSources) {
                    if (source != null && source.startsWith("yt2009|")) addPlaybackSourceTag(orderedSources, source);
                }

                // Add the suggestion's own backend/instance immediately after yt2009. This makes
                // a Piped/Invidious search result resolvable on its supplying host even when the
                // rest of the instance list is stale or one of its APIs is offline.
                String suggestionSource = sourceTagFromProvider(item.provider);
                if (suggestionSource != null) addPlaybackSourceTag(orderedSources, suggestionSource);

                // Current provider and last working provider are valid candidates even if the
                // discovery registry changed while the player stayed open.
                addPlaybackSource(orderedSources, relatedProviderName, relatedProviderBase);
                addPlaybackSource(orderedSources,
                    prefs.getString("last_good_playback_type", ""),
                    prefs.getString("last_good_playback_base", ""));

                String[] sourceOrder = new String[] {"YtAPILegacy", "Invidious", "Piped"};
                for (int t = 0; t < sourceOrder.length; t++) {
                    String prefix = sourceOrder[t] + "|";
                    for (String source : relatedSources) {
                        if (source != null && source.startsWith(prefix)) addPlaybackSourceTag(orderedSources, source);
                    }
                }

                for (int i = 0; i < orderedSources.size() && attempted < 10; i++) {
                    String encoded = orderedSources.get(i);
                    int split = encoded.indexOf('|');
                    if (split <= 0 || split >= encoded.length() - 1) continue;
                    String name = encoded.substring(0, split);
                    String base = encoded.substring(split + 1);
                    Provider provider = makeProvider(name, base);
                    if (provider == null) continue;
                    attempted++;
                    try {
                        List<StreamItem> result = provider.streams(item.id);
                        if (result != null) for (StreamItem stream : result) {
                            if (stream != null && HttpJson.isHttpUrl(stream.url)) {
                                stream.providerName = name;
                                stream.providerBase = base;
                                stream.label = displaySourceLabel(name, base, stream.label);
                                boolean duplicate = false;
                                for (StreamItem existing : choices) if (stream.url.equals(existing.url)) { duplicate = true; break; }
                                if (!duplicate) choices.add(stream);
                            }
                        }
                    } catch (Exception ignored) {}
                }
                runOnUiThread(new Runnable() {
                    public void run() {
                        spinner.setVisibility(View.GONE);
                        if (choices.size() == 0) {
                            status.setText("Couldn't find a stream for that related video. The current video is still selected.");
                            return;
                        }
                        Collections.sort(choices, new Comparator<StreamItem>() {
                            public int compare(StreamItem a, StreamItem b) {
                                int ap = playbackPriority(a.providerName);
                                int bp = playbackPriority(b.providerName);
                                if (ap != bp) return ap - bp;
                                int ah = a.height > 0 ? Math.abs(a.height - 360) : 10000;
                                int bh = b.height > 0 ? Math.abs(b.height - 360) : 10000;
                                return ah - bh;
                            }
                        });
                        title = item.title == null ? "ClassicTube Player" : item.title;
                        videoId = item.id;
                        titleView.setText(title);
                        failedUrls.clear();
                        streamIndex = 0;
                        urls = new String[choices.size()];
                        labels = new String[choices.size()];
                        mimes = new String[choices.size()];
                        providerNames = new String[choices.size()];
                        providerBases = new String[choices.size()];
                        for (int i = 0; i < choices.size(); i++) {
                            urls[i] = choices.get(i).url;
                            labels[i] = choices.get(i).label;
                            mimes[i] = choices.get(i).mimeType == null ? "video/*" : choices.get(i).mimeType;
                            providerNames[i] = choices.get(i).providerName == null ? "" : choices.get(i).providerName;
                            providerBases[i] = choices.get(i).providerBase == null ? "" : choices.get(i).providerBase;
                        }
                        relatedProviderName = choices.get(0).providerName;
                        relatedProviderBase = choices.get(0).providerBase;
                        activateProviderForIndex(0);
                        currentUrl = urls[0];
                        currentMime = mimes[0];
                        currentLabel = labels[0];
                        sourceView.setText(currentLabel);
                        startStream(currentUrl, currentMime, currentLabel, 0);
                        relatedScroll.smoothScrollTo(0, 0);
                        relatedContainer.removeAllViews();
                        loadRelatedVideos();
                    }
                });
            }
        }, "ClassicTube-play-related").start();
    }

    private void addPlaybackSource(ArrayList<String> target, String name, String base) {
        if (target == null || name == null || base == null) return;
        name = name.trim();
        base = base.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        if (!("yt2009".equals(name) || "YtAPILegacy".equals(name) || "Invidious".equals(name) || "Piped".equals(name))) return;
        if (!HttpJson.isHttpUrl(base)) return;
        String tag = name + "|" + base;
        if (!target.contains(tag)) target.add(tag);
    }

    private void addPlaybackSourceTag(ArrayList<String> target, String tag) {
        if (tag == null) return;
        int split = tag.indexOf('|');
        if (split <= 0 || split >= tag.length() - 1) return;
        addPlaybackSource(target, tag.substring(0, split), tag.substring(split + 1));
    }

    private String sourceTagFromProvider(String provider) {
        if (provider == null) return null;
        int open = provider.indexOf(" (");
        int close = provider.lastIndexOf(')');
        if (open <= 0 || close <= open + 2) return null;
        String name = provider.substring(0, open).trim();
        String base = provider.substring(open + 2, close).trim();
        if (!("yt2009".equals(name) || "YtAPILegacy".equals(name) || "Invidious".equals(name) || "Piped".equals(name))) return null;
        if (!HttpJson.isHttpUrl(base)) return null;
        return name + "|" + base;
    }

    private void activateProviderForIndex(int index) {
        if (providerNames != null && index >= 0 && index < providerNames.length && providerNames[index] != null && providerNames[index].length() > 0) {
            relatedProviderName = providerNames[index];
        }
        if (providerBases != null && index >= 0 && index < providerBases.length && providerBases[index] != null && providerBases[index].length() > 0) {
            relatedProviderBase = providerBases[index];
        }
    }

    private void rememberSuccessfulPlaybackSource() {
        if (relatedProviderName == null || relatedProviderName.length() == 0 || relatedProviderBase == null || relatedProviderBase.length() == 0) return;
        SharedPreferences prefs = getSharedPreferences("classictube", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit()
            .putString("last_good_playback_type", relatedProviderName)
            .putString("last_good_playback_base", relatedProviderBase);
        if ("yt2009".equals(relatedProviderName)) editor.putString("last_good_yt2009", relatedProviderBase);
        editor.commit();
    }

    private void cancelPlaybackTimeout() {
        if (playbackTimeoutRunnable != null) {
            playbackHandler.removeCallbacks(playbackTimeoutRunnable);
            playbackTimeoutRunnable = null;
        }
    }

    private void schedulePlaybackTimeout(final String expectedUrl) {
        cancelPlaybackTimeout();
        playbackTimeoutRunnable = new Runnable() {
            public void run() {
                if (!prepared && expectedUrl != null && expectedUrl.equals(currentUrl)) {
                    failedUrls.add(expectedUrl);
                    advanceAfterFailure("This stream took too long to start. Trying another source...");
                }
            }
        };
        // Old devices and community instances can stall without raising MediaPlayer errors.
        playbackHandler.postDelayed(playbackTimeoutRunnable, 18000L);
    }

    private int nextUnfailedStreamIndex() {
        if (urls == null || urls.length == 0) return -1;
        for (int offset = 1; offset <= urls.length; offset++) {
            int index = (Math.max(0, streamIndex) + offset) % urls.length;
            String candidate = urls[index];
            if (candidate == null || candidate.length() == 0 || candidate.equals(currentUrl) || failedUrls.contains(candidate)) continue;
            return index;
        }
        return -1;
    }

    private void advanceAfterFailure(String reason) {
        int nextIndex = nextUnfailedStreamIndex();
        if (nextIndex < 0) {
            cancelPlaybackTimeout();
            spinner.setVisibility(View.GONE);
            status.setText(reason + " All returned sources have now failed. Try Retry, go back and choose another video, or configure a working yt2009 instance in Sources.");
            return;
        }
        streamIndex = nextIndex;
        activateProviderForIndex(streamIndex);
        String label = labels != null && streamIndex < labels.length ? labels[streamIndex] : "Alternate source";
        String mime = mimes != null && streamIndex < mimes.length ? mimes[streamIndex] : "video/*";
        status.setText(reason + " Next: " + label);
        startStream(urls[streamIndex], mime, label, 0);
    }

    private void startStream(String url, String mime, String label, int seekPosition) {
        if (url == null || url.length() == 0) {
            status.setText("This source did not provide a stream URL.");
            spinner.setVisibility(View.GONE);
            return;
        }
        cancelPlaybackTimeout();
        currentUrl = url;
        currentMime = mime == null || mime.length() == 0 ? "video/*" : mime;
        currentLabel = label == null ? "Video stream" : label;
        if (sourceView != null) sourceView.setText(currentLabel);
        if (status != null) status.setText("Connecting to stream...");
        if (spinner != null) spinner.setVisibility(View.VISIBLE);
        prepared = false;
        savedPosition = seekPosition;
        try {
            videoView.stopPlayback();
            videoView.setVideoURI(Uri.parse(currentUrl));
            videoView.requestFocus();
            schedulePlaybackTimeout(currentUrl);
        } catch (Exception e) {
            failedUrls.add(currentUrl);
            advanceAfterFailure("Could not open the stream URL. Trying another source...");
        }
    }

    private void playNextSource() {
        if (currentUrl != null) failedUrls.add(currentUrl);
        advanceAfterFailure("Switching source...");
    }

    private void openExternal() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(currentUrl), currentMime.split(";")[0]);
            startActivity(intent);
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))); }
            catch (Exception ignored) { Toast.makeText(this, "No compatible external player is installed.", Toast.LENGTH_LONG).show(); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        try {
            if (videoView != null && videoView.isPlaying()) {
                savedPosition = videoView.getCurrentPosition();
                videoView.pause();
                wasPlaying = true;
            }
        } catch (Exception ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (videoView != null && prepared && wasPlaying) {
            try { videoView.seekTo(savedPosition); videoView.start(); }
            catch (Exception ignored) {}
        }
    }

    @Override protected void onDestroy() {
        cancelPlaybackTimeout();
        try { if (videoView != null) videoView.stopPlayback(); } catch (Exception ignored) {}
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
}
