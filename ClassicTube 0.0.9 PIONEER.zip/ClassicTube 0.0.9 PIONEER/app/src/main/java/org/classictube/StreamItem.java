package org.classictube;

public class StreamItem {
    public String label;
    public String url;
    public String mimeType;
    public int height;
    // Filled by MainActivity when a stream is discovered, so related-video lookup
    // can prefer the exact backend instance that supplied the current stream.
    public String providerName = "";
    public String providerBase = "";

    public StreamItem(String label, String url, String mimeType, int height) {
        this.label = label;
        this.url = url;
        this.mimeType = mimeType;
        this.height = height;
    }

    public String toString() { return label; }
}
