# ClassicTube 0.1 — legacy Android starter project

A lightweight, native Java Android client prototype targeting Android 2.2 (API 8). It has no AndroidX, Kotlin, Google Play Services, login, account features, or Shorts UI.

## Included in this prototype

- Classic YouTube-inspired native UI
- Search field
- Thumbnail loading with downsampling and simple tag checks
- Invidious and Piped metadata provider adapters
- Sequential provider failover and duplicate-video removal
- Best-effort stream discovery and quality chooser
- External-player intent and browser fallback
- No login or account support

## Important limitations

This is a **starter implementation, not a verified production-ready YouTube client**. Public instances may be offline, rate-limited, blocked, or have changed their APIs. The default endpoint list is only a starting point; edit the instance list in `MainActivity.java` or add a settings screen before release.

- Invidious and Piped endpoints are not guaranteed to return the same fields on every instance.
- The stream chooser is best-effort. Direct stream URLs can expire, be unavailable, or be rejected by external players.
- This does not implement server-side transcoding.
- yt2009 is primarily a legacy web frontend and does not automatically expose the same JSON API as Invidious/Piped. An adapter should only be added after the exact deployment/API contract is verified.
- `YtAPILegacy` is not included because the exact project and documented endpoint contract have not yet been verified.
- Android 2.2's old TLS/certificate stack may fail to connect to modern HTTPS servers even when the Java code is compatible. Do not disable certificate validation to work around this.
- Many Android 2.2 devices cannot decode some streams. The app offers a browser fallback; actual playback depends on device codecs, external players, and provider responses.
- The app currently uses a basic layout and has no persistent watch history, pagination, advanced settings, or provider health scoring.
- The app does not promise compatibility with all YouTube content or service changes.

## Build

Open this directory in a compatible Android Studio installation and let Gradle sync. The project uses Android Gradle Plugin 7.4.2, compile SDK 33, target SDK 28, and Java 7 source compatibility. You will need a compatible JDK/Gradle setup and the Android SDK platform/build tools.

Because the Android 2.2 platform is extremely old, test on a real legacy device or a suitable emulator. A successful build does not guarantee that all current HTTPS endpoints will connect from that device.

## Provider references

- Invidious API documentation: https://docs.invidious.io/api/
- Piped API documentation: https://docs.piped.video/docs/api-documentation/
- yt2009 project: https://github.com/ftde0/yt2009

## Next engineering steps

1. Add an editable provider settings screen.
2. Add a curated, regularly checked public-instance list.
3. Test endpoint response schemas and add robust JSON validation.
4. Add provider-specific playback capability scoring.
5. Add local history and pagination.
6. Test APK size, memory usage, TLS, and actual codecs on target devices.
7. Add any yt2009/YtAPILegacy adapters only after confirming their exact API contracts.
