package org.classictube;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class InvidiousProvider implements Provider {
    private final String base;
    public InvidiousProvider(String base) { this.base = trim(base); }
    public String getName() { return "Invidious"; }

    public List<VideoItem> search(String query) throws Exception {
        JSONArray a = HttpJson.array(HttpJson.get(base + "/api/v1/search?q=" + HttpJson.enc(query) + "&type=video&page=1"));
        List<VideoItem> out = new ArrayList<VideoItem>();
        for (int i = 0; i < a.length() && out.size() < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !"video".equals(o.optString("type", "video"))) continue;
            String id = o.optString("videoId", "");
            if (id.length() == 0) continue;
            VideoItem v = new VideoItem();
            v.id = id;
            v.title = o.optString("title", "Untitled");
            v.author = o.optString("author", "");
            v.duration = duration(o.optInt("lengthSeconds", 0));
            v.thumbnail = thumb(o.optJSONArray("videoThumbnails"));
            v.provider = getName() + " (" + base + ")";
            out.add(v);
        }
        if (out.size() == 0) throw new Exception("No video results");
        return out;
    }

    public List<StreamItem> streams(String videoId) throws Exception {
        JSONObject o = HttpJson.object(HttpJson.get(base + "/api/v1/videos/" + HttpJson.enc(videoId)));
        List<StreamItem> out = new ArrayList<StreamItem>();
        JSONArray formats = o.optJSONArray("formatStreams");
        addFormats(out, formats);
        JSONArray adaptive = o.optJSONArray("adaptiveFormats");
        addFormats(out, adaptive);
        if (out.size() == 0) throw new Exception("This instance returned no direct streams");
        return out;
    }

    private void addFormats(List<StreamItem> out, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject f = a.optJSONObject(i);
            if (f == null) continue;
            String url = f.optString("url", "");
            if (url.length() == 0) continue;
            String q = HttpJson.firstString(f, "qualityLabel", "quality", "resolution");
            String mime = HttpJson.firstString(f, "type", "mimeType");
            int h = parseHeight(q);
            String label = (q.length() > 0 ? q : "Available stream") + (mime.length() > 0 ? " · " + mime.split(";")[0] : "");
            out.add(new StreamItem(label, url, mime, h));
        }
    }

    private String thumb(JSONArray a) {
        if (a == null) return "";
        String fallback = "";
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.optJSONObject(i);
            if (t == null) continue;
            String url = t.optString("url", "");
            if (url.length() == 0) continue;
            fallback = url;
            String q = t.optString("quality", "");
            if ("medium".equals(q) || "mediumQuality".equals(q) || "default".equals(q)) return url;
        }
        return fallback;
    }

    private static int parseHeight(String q) {
        if (q == null) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3,4})p").matcher(q);
        if (m.find()) try { return Integer.parseInt(m.group(1)); } catch (Exception e) {}
        return 0;
    }
    private static String duration(int s) {
        if (s <= 0) return "";
        return String.format("%d:%02d", s / 60, s % 60);
    }
    private static String trim(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
