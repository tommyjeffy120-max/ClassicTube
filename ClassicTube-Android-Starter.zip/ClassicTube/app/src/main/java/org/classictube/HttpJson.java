package org.classictube;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public final class HttpJson {
    private HttpJson() {}

    public static String get(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(7000);
        c.setReadTimeout(9000);
        c.setRequestProperty("User-Agent", "ClassicTube/0.1 (Android legacy client)");
        c.setRequestProperty("Accept", "application/json");
        try {
            int status = c.getResponseCode();
            InputStream in = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new Exception("HTTP " + status);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            in.close();
            String body = new String(out.toByteArray(), "UTF-8");
            if (status < 200 || status >= 300) throw new Exception("HTTP " + status);
            return body;
        } finally {
            c.disconnect();
        }
    }

    public static JSONArray array(String body) throws Exception {
        return new JSONArray(body);
    }

    public static JSONObject object(String body) throws Exception {
        return new JSONObject(body);
    }

    public static String enc(String s) throws Exception {
        return java.net.URLEncoder.encode(s, "UTF-8");
    }

    public static String firstString(JSONObject o, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            String v = o.optString(keys[i], "");
            if (v != null && v.length() > 0 && !"null".equals(v)) return v;
        }
        return "";
    }
}
