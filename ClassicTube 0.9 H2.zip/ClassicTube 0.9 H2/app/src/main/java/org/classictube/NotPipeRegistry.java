package org.classictube;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Fetches and caches notPipe's public instance registry, with a safe empty fallback. */
public final class NotPipeRegistry {
    public static final String FEED_URL = "http://144.31.189.129/notPipe.json";
    private static final String PREFS = "classictube";
    private static final String CACHE_KEY = "notpipe_registry_json";
    private static final String CACHE_TIME_KEY = "notpipe_registry_saved_at";
    private static final String LAST_FEED_ATTEMPT_KEY = "notpipe_registry_last_attempt_at";
    private static final String INVIDIOUS_URL = "https://api.invidious.io/instances.json";
    private static final String INVIDIOUS_CACHE_KEY = "invidious_api_instances_json";
    private static final String INVIDIOUS_CACHE_TIME_KEY = "invidious_api_instances_saved_at";
    private static final String PIPED_INSTANCES_URL = "https://piped-instances.kavin.rocks/";
    private static final String PIPED_DOCS_URL = "https://raw.githubusercontent.com/TeamPiped/documentation/main/content/docs/public-instances/index.md";
    private static final String PIPED_CACHE_KEY = "piped_api_instances_json";
    private static final String PIPED_CACHE_TIME_KEY = "piped_api_instances_saved_at";
    private static final long PIPED_CACHE_MAX_AGE_MS = 12L * 60L * 60L * 1000L;
    private static final long CACHE_MAX_AGE_MS = 6L * 60L * 60L * 1000L;
    private static final long INVIDIOUS_CACHE_MAX_AGE_MS = 12L * 60L * 60L * 1000L;

    public static final class Data {
        public final List<String> invidious = new ArrayList<String>();
        public final List<String> apiEnabledInvidious = new ArrayList<String>();
        public final List<String> piped = new ArrayList<String>();
        public final List<String> yt2009 = new ArrayList<String>();
        public final List<String> ytApiLegacy = new ArrayList<String>();
    }

    private NotPipeRegistry() {}

    public static Data fetch(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cached = prefs.getString(CACHE_KEY, null);
        long savedAt = prefs.getLong(CACHE_TIME_KEY, 0L);
        long now = System.currentTimeMillis();
        // Reuse a recent registry immediately: the public feed can be slow or unavailable.
        if (cached != null && cached.length() > 0 && now - savedAt >= 0 && now - savedAt < CACHE_MAX_AGE_MS) {
            return addPipedInstances(context, addApiEnabledInvidious(context, parse(cached)));
        }
        String json = cached;
        long lastAttempt = prefs.getLong(LAST_FEED_ATTEMPT_KEY, 0L);
        // The older notPipe feed has been unreachable in recent builds. Retry it at most
        // once per six hours rather than adding seconds of delay to every search.
        if (now - lastAttempt >= CACHE_MAX_AGE_MS || lastAttempt > now) {
            prefs.edit().putLong(LAST_FEED_ATTEMPT_KEY, now).commit();
            try {
                String live = HttpJson.get(FEED_URL, 900, 1200);
                if (live != null && live.length() > 0) {
                    json = live;
                    prefs.edit().putString(CACHE_KEY, json).putLong(CACHE_TIME_KEY, now).commit();
                }
            } catch (Exception ignored) {
                // Reuse cached data if the notPipe feed is unavailable.
            }
        }
        return addPipedInstances(context, addApiEnabledInvidious(context, parse(json)));
    }

    /**
     * Merge the maintained Piped instance API into a persistent cache. If it is offline,
     * try the project's public-instance table; the app's curated defaults remain the final fallback.
     */
    private static Data addPipedInstances(Context context, Data data) {
        if (data == null) data = new Data();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cached = prefs.getString(PIPED_CACHE_KEY, null);
        long savedAt = prefs.getLong(PIPED_CACHE_TIME_KEY, 0L);
        long now = System.currentTimeMillis();
        boolean fresh = cached != null && cached.length() > 0 && now - savedAt >= 0 && now - savedAt < PIPED_CACHE_MAX_AGE_MS;
        if (!fresh) {
            String live = null;
            try {
                live = HttpJson.get(PIPED_INSTANCES_URL, 1200, 1800);
                // Verify that the response is a JSON list before caching it.
                JSONArray check = new JSONArray(live);
                if (check.length() == 0) live = null;
            } catch (Exception ignored) { live = null; }
            if (live == null) {
                try {
                    String markdown = HttpJson.get(PIPED_DOCS_URL, 1200, 1800);
                    JSONArray urls = parsePipedMarkdown(markdown);
                    if (urls.length() > 0) live = urls.toString();
                } catch (Exception ignored) { live = null; }
            }
            if (live != null && live.length() > 0) {
                cached = live;
                prefs.edit().putString(PIPED_CACHE_KEY, cached).putLong(PIPED_CACHE_TIME_KEY, now).commit();
            }
        }
        if (cached == null || cached.length() == 0) return data;
        try {
            JSONArray entries = new JSONArray(cached);
            for (int i = 0; i < entries.length() && data.piped.size() < 40; i++) {
                Object item = entries.opt(i);
                String base = "";
                if (item instanceof JSONObject) {
                    JSONObject object = (JSONObject) item;
                    base = HttpJson.firstString(object, "api_url", "apiUrl", "url");
                } else if (item instanceof String) {
                    base = (String) item;
                }
                base = trim(base);
                if (!base.startsWith("https://")) continue;
                if (base.contains(" ") || base.contains("/healthcheck")) continue;
                if (!data.piped.contains(base)) data.piped.add(base);
            }
        } catch (Exception ignored) {
            // Keep the registry data we already had; MainActivity includes curated defaults.
        }
        return data;
    }

    private static JSONArray parsePipedMarkdown(String markdown) {
        JSONArray out = new JSONArray();
        if (markdown == null) return out;
        String[] lines = markdown.split("\\r?\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.indexOf('|') < 0) continue;
            String cleanLine = line.trim();
            if (cleanLine.startsWith("|")) cleanLine = cleanLine.substring(1);
            if (cleanLine.endsWith("|")) cleanLine = cleanLine.substring(0, cleanLine.length() - 1);
            String[] columns = cleanLine.split("\\|");
            if (columns.length < 2) continue;
            String url = columns[1].trim();
            if (!url.startsWith("https://")) continue;
            // Only API-like endpoints belong here; avoid adding the frontend URL.
            String lower = url.toLowerCase(Locale.US);
            if (!(lower.contains("pipedapi") || lower.contains("piped-api") ||
                  lower.contains("api-piped") || lower.contains("piped-backend") ||
                  lower.contains("watchapi") || lower.contains("pdapi."))) continue;
            url = trim(url);
            if (url.length() > 8) out.put(url);
        }
        return out;
    }

    /** Adds only HTTPS Invidious instances whose maintained registry explicitly enables the API. */
    private static Data addApiEnabledInvidious(Context context, Data data) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = prefs.getString(INVIDIOUS_CACHE_KEY, null);
        long savedAt = prefs.getLong(INVIDIOUS_CACHE_TIME_KEY, 0L);
        long now = System.currentTimeMillis();
        boolean fresh = json != null && json.length() > 0 && now - savedAt >= 0 && now - savedAt < INVIDIOUS_CACHE_MAX_AGE_MS;
        if (!fresh) {
            try {
                String live = HttpJson.get(INVIDIOUS_URL, 2200, 3200);
                if (live != null && live.length() > 0) {
                    json = live;
                    prefs.edit().putString(INVIDIOUS_CACHE_KEY, json).putLong(INVIDIOUS_CACHE_TIME_KEY, now).commit();
                }
            } catch (Exception ignored) {
                // Use the last cached response, or the static known-good fallback if there is none.
            }
        }
        if (json == null || json.length() == 0 || data == null) return data;
        try {
            JSONArray entries = new JSONArray(json);
            for (int i = 0; i < entries.length(); i++) {
                JSONArray entry = entries.optJSONArray(i);
                if (entry == null || entry.length() < 2) continue;
                JSONObject info = entry.optJSONObject(1);
                if (info == null || !info.optBoolean("api", false)) continue;
                if (!"https".equalsIgnoreCase(info.optString("type", ""))) continue;
                String uri = info.optString("uri", "").trim();
                if (!uri.startsWith("https://")) continue;
                JSONObject monitor = info.optJSONObject("monitor");
                if (monitor != null && monitor.optBoolean("down", false)) continue;
                uri = trim(uri);
                if (!data.apiEnabledInvidious.contains(uri)) data.apiEnabledInvidious.add(uri);
            }
        } catch (Exception ignored) {
        }
        return data;
    }

    private static Data parse(String json) {
        if (json == null || json.length() == 0) return new Data();
        try {
            Data data = new Data();
            walk(new JSONObject(json), "", data);
            return data;
        } catch (Exception ignored) {
            return new Data();
        }
    }

    private static void walk(Object node, String inheritedType, Data out) {
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            String type = inheritedType;
            String[] typeKeys = new String[] {"type", "api", "provider", "backend", "name"};
            for (int i = 0; i < typeKeys.length; i++) {
                String candidate = inferType(obj.optString(typeKeys[i], ""));
                if (candidate.length() > 0) { type = candidate; break; }
            }
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object value = obj.opt(key);
                String childType = inferType(key);
                if (childType.length() == 0) childType = type;
                if (value instanceof String) {
                    addUrl((String) value, childType, out);
                } else {
                    walk(value, childType, out);
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) walk(arr.opt(i), inheritedType, out);
        } else if (node instanceof String) {
            addUrl((String) node, inheritedType, out);
        }
    }

    private static void addUrl(String value, String type, Data out) {
        if (value == null) return;
        String v = value.trim();
        if (!(v.startsWith("http://") || v.startsWith("https://"))) return;
        String t = inferType(type);
        if (t.length() == 0) return;
        // notPipe's Piped entries may be "API base,proxy base"; ClassicTube needs API base.
        if ("piped".equals(t) && v.indexOf(',') >= 0) v = v.substring(0, v.indexOf(',')).trim();
        v = trim(v);
        List<String> target = listFor(t, out);
        if (target != null && !target.contains(v)) target.add(v);
    }

    private static String inferType(String raw) {
        if (raw == null) return "";
        String s = raw.toLowerCase(Locale.US).replace("_", "").replace("-", "").replace(" ", "");
        if (s.contains("invidious")) return "invidious";
        if (s.contains("ytapilegacy") || s.contains("ytapi") || s.contains("legacy")) return "ytapilegacy";
        if (s.contains("yt2009")) return "yt2009";
        if (s.contains("piped")) return "piped";
        return "";
    }

    private static List<String> listFor(String type, Data out) {
        if ("invidious".equals(type)) return out.invidious;
        if ("piped".equals(type)) return out.piped;
        if ("yt2009".equals(type)) return out.yt2009;
        if ("ytapilegacy".equals(type)) return out.ytApiLegacy;
        return null;
    }

    private static String trim(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
