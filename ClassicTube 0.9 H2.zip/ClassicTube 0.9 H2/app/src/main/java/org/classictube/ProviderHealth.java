package org.classictube;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/**
 * Small persistent circuit breaker for flaky public API instances.
 * Failures are scoped by provider + host + operation, so a search failure does not
 * automatically disable playback. Cooldowns expire automatically; no host is
 * permanently blacklisted.
 */
public final class ProviderHealth {
    private static final String PREFS = "classictube_provider_health";
    private static final long HOUR = 60L * 60L * 1000L;
    private static final long DAY = 24L * HOUR;

    private ProviderHealth() {}

    private static String prefix(String provider, String base, String operation) {
        String p = clean(provider);
        String b = clean(base).toLowerCase(Locale.US);
        String o = clean(operation);
        return p + "|" + o + "|" + b;
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim();
    }

    public static boolean isCoolingDown(Context context, String provider, String base, String operation) {
        if (context == null || clean(base).length() == 0) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getLong(prefix(provider, base, operation) + "|until", 0L) > System.currentTimeMillis();
    }

    public static void recordSuccess(Context context, String provider, String base, String operation) {
        if (context == null || clean(base).length() == 0) return;
        String key = prefix(provider, base, operation);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().remove(key + "|until").remove(key + "|count").remove(key + "|reason").commit();
    }

    public static void recordFailure(Context context, String provider, String base, String operation, Throwable error) {
        if (context == null || clean(base).length() == 0 || error == null) return;
        String message = collectMessages(error).toLowerCase(Locale.US);
        // These are failures of one video/format, not necessarily of the host.
        if (message.contains("no compatible") || message.contains("no video results") ||
            message.contains("invalid video id") || message.contains("no stream formats")) return;

        long baseCooldown;
        long maxCooldown;
        String reason;
        if (message.contains("unable to resolve host") || message.contains("unknownhostexception") ||
            message.contains("no address associated with hostname") || message.contains("name or service not known")) {
            baseCooldown = 6L * HOUR;
            maxCooldown = DAY;
            reason = "DNS";
        } else if (message.contains("ssl") || message.contains("handshake") ||
                   message.contains("certificate") || message.contains("protocol_error")) {
            baseCooldown = 6L * HOUR;
            maxCooldown = DAY;
            reason = "TLS";
        } else if (message.contains("http 429") || message.contains("too many requests")) {
            baseCooldown = 30L * 60L * 1000L;
            maxCooldown = 4L * HOUR;
            reason = "rate-limited";
        } else if (message.contains("http 5") || message.contains("bad gateway") ||
                   message.contains("gateway timeout") || message.contains("service unavailable")) {
            baseCooldown = 20L * 60L * 1000L;
            maxCooldown = 4L * HOUR;
            reason = "server error";
        } else if (message.contains("timed out") || message.contains("timeout") || message.contains("took too long") ||
                   message.contains("connectexception") || message.contains("connection reset")) {
            baseCooldown = 10L * 60L * 1000L;
            maxCooldown = 2L * HOUR;
            reason = "connection timeout";
        } else if (message.contains("unexpected char '<'") || message.contains("html instead of json") ||
                   message.contains("malformed json") || message.contains("json response")) {
            baseCooldown = 20L * 60L * 1000L;
            maxCooldown = 4L * HOUR;
            reason = "invalid response";
        } else {
            baseCooldown = 5L * 60L * 1000L;
            maxCooldown = HOUR;
            reason = "temporary failure";
        }

        String key = prefix(provider, base, operation);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int count = Math.min(5, prefs.getInt(key + "|count", 0) + 1);
        long multiplier = 1L << Math.min(4, count - 1);
        long cooldown = Math.min(maxCooldown, baseCooldown * multiplier);
        prefs.edit().putInt(key + "|count", count)
            .putLong(key + "|until", System.currentTimeMillis() + cooldown)
            .putString(key + "|reason", reason).commit();
    }

    /** Seed endpoints already observed to fail in older app versions; they expire normally. */
    public static void seedCooldownIfUnknown(Context context, String provider, String base,
                                             String operation, long durationMs, String reason) {
        if (context == null || clean(base).length() == 0) return;
        String key = prefix(provider, base, operation);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.contains(key + "|until")) return;
        prefs.edit().putInt(key + "|count", 1)
            .putLong(key + "|until", System.currentTimeMillis() + Math.max(0L, durationMs))
            .putString(key + "|reason", reason == null ? "previously failed" : reason).commit();
    }

    private static String collectMessages(Throwable error) {
        StringBuilder out = new StringBuilder();
        Throwable current = error;
        int depth = 0;
        while (current != null && depth < 5) {
            if (current.getMessage() != null) out.append(' ').append(current.getMessage());
            out.append(' ').append(current.getClass().getName());
            current = current.getCause();
            depth++;
        }
        return out.toString();
    }
}
