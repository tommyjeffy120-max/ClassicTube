package org.classictube;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public final class HttpJson {
    private HttpJson() {}

    public static String get(String address) throws Exception {
        return get(address, 7000, 9000);
    }

    public static String get(String address, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection c = null;
        InputStream in = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(Math.max(500, connectTimeout));
            c.setReadTimeout(Math.max(700, readTimeout));
            c.setInstanceFollowRedirects(true);
            c.setUseCaches(false);
            c.setRequestProperty("User-Agent", "ClassicTube/0.0.9.1 (legacy Android client)");
            c.setRequestProperty("Accept", "application/json, text/plain, text/html, */*");

            int status = c.getResponseCode();
            in = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new Exception("HTTP " + status + " (empty response)");

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > 4 * 1024 * 1024) throw new Exception("Response was too large (over 4 MiB)");
                out.write(buffer, 0, n);
            }
            String body = new String(out.toByteArray(), "UTF-8");
            if (status < 200 || status >= 300) {
                String detail = body == null ? "" : body.replace('\n', ' ').replace('\r', ' ').trim();
                if (detail.length() > 160) detail = detail.substring(0, 160) + "…";
                throw new Exception("HTTP " + status + (detail.length() == 0 ? "" : ": " + detail));
            }
            return body;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            if (c != null) c.disconnect();
        }
    }

    public static JSONArray array(String body) throws Exception {
        String json = requireJson(body, '[');
        return new JSONArray(json);
    }

    public static JSONObject object(String body) throws Exception {
        String json = requireJson(body, '{');
        return new JSONObject(json);
    }

    private static String requireJson(String body, char expected) throws Exception {
        if (body == null) throw new Exception("Empty response; expected JSON");
        String value = body.trim();
        if (value.length() == 0) throw new Exception("Empty response; expected JSON");
        if (value.charAt(0) == '<') {
            throw new Exception("Server returned HTML instead of JSON (often an error page or proxy response)");
        }
        if (value.charAt(0) != expected) {
            throw new Exception("Unexpected response format; expected JSON " + (expected == '[' ? "array" : "object"));
        }
        return value;
    }

    public static String enc(String s) throws Exception {
        return java.net.URLEncoder.encode(s, "UTF-8");
    }

    public static String firstString(JSONObject o, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            String v = o.optString(keys[i], "");
            if (v != null && v.length() > 0 && !"null".equals(v)) return v;
        }
        return "";
    }

    public static String resolveUrl(String base, String value) {
        if (value == null || value.length() == 0 || "null".equals(value)) return "";
        try {
            return new URL(new URL(base.endsWith("/") ? base : base + "/"), value).toString();
        } catch (Exception ignored) {
            return value;
        }
    }

    public static boolean isHttpUrl(String value) {
        return value != null && (value.startsWith("https://") || value.startsWith("http://"));
    }
}
