package org.classictube;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class InvidiousProvider implements Provider, SuggestionProvider {
    private final String base;
    public InvidiousProvider(String base) { this.base = trim(base); }
    public String getName() { return "Invidious"; }
    public String getBase() { return base; }

    public List<String> suggestions(String query) throws Exception {
        String address = base + "/api/v1/search/suggestions?q=" + HttpJson.enc(query);
        JSONObject obj = HttpJson.object(HttpJson.get(address, 1400, 1900));
        JSONArray a = obj.optJSONArray("suggestions");
        if (a == null) throw new Exception("Suggestion response did not contain a list");
        List<String> out = new ArrayList<String>();
        for (int i = 0; i < a.length() && out.size() < 6; i++) {
            String value = a.optString(i, "").trim();
            if (value.length() > 0 && !out.contains(value)) out.add(value);
        }
        return out;
    }

    public List<VideoItem> search(String query) throws Exception {
        JSONArray a = HttpJson.array(HttpJson.get(base + "/api/v1/search?q=" + HttpJson.enc(query) + "&type=video&page=1", 4000, 5500));
        List<VideoItem> out = new ArrayList<VideoItem>();
        for (int i = 0; i < a.length() && out.size() < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !"video".equals(o.optString("type", "video"))) continue;
            String id = o.optString("videoId", "");
            if (id.length() == 0) continue;
            VideoItem v = new VideoItem();
            v.id = id;
            v.title = o.optString("title", "Untitled");
            v.author = o.optString("author", "");
            v.duration = duration(o.optInt("lengthSeconds", 0));
            v.thumbnail = thumb(o.optJSONArray("videoThumbnails"));
            v.provider = getName() + " (" + base + ")";
            out.add(v);
        }
        if (out.size() == 0) throw new Exception("No video results");
        return out;
    }

    /**
     * Fetch recommendations from this Invidious instance.
     * Current Invidious API versions expose recommendations in the video-details
     * response. The older /related endpoint is retained as a compatibility fallback
     * for instances which still implement it.
     */
    public List<VideoItem> relatedVideos(String videoId) throws Exception {
        if (!validVideoId(videoId)) throw new Exception("Invalid video ID for recommendations");

        Exception primaryFailure = null;
        try {
            String address = base + "/api/v1/videos/" + HttpJson.enc(videoId);
            JSONObject response = HttpJson.object(HttpJson.get(address, 2000, 2800));
            JSONArray recommendations = response.optJSONArray("recommendedVideos");
            if (recommendations == null) recommendations = response.optJSONArray("relatedVideos");
            if (recommendations != null) {
                List<VideoItem> out = parseRelatedVideos(recommendations, videoId);
                if (!out.isEmpty()) return out;
            }
            primaryFailure = new Exception("Video API returned no usable recommendations");
        } catch (Exception e) {
            primaryFailure = e;
        }

        // Compatibility fallback for older / modified Invidious instances.
        try {
            String address = base + "/api/v1/related?id=" + HttpJson.enc(videoId);
            String body = HttpJson.get(address, 1200, 1600);
            JSONArray recommendations;
            if (body != null && body.trim().startsWith("[")) {
                recommendations = HttpJson.array(body);
            } else {
                JSONObject response = HttpJson.object(body);
                recommendations = response.optJSONArray("recommendedVideos");
                if (recommendations == null) recommendations = response.optJSONArray("relatedVideos");
                if (recommendations == null) recommendations = response.optJSONArray("items");
                if (recommendations == null) recommendations = response.optJSONArray("videos");
            }
            if (recommendations != null) return parseRelatedVideos(recommendations, videoId);
            throw new Exception("Related API response contained no recommendation list");
        } catch (Exception compatibilityFailure) {
            if (primaryFailure != null) {
                throw new Exception("Invidious video and related recommendation APIs failed", compatibilityFailure);
            }
            throw compatibilityFailure;
        }
    }

    private List<VideoItem> parseRelatedVideos(JSONArray a, String currentVideoId) {
        List<VideoItem> out = new ArrayList<VideoItem>();
        if (a == null) return out;
        for (int i = 0; i < a.length() && out.size() < 6; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = HttpJson.firstString(o, "videoId", "id");
            if (!validVideoId(id) || currentVideoId.equals(id)) continue;
            if (o.has("type") && !"video".equals(o.optString("type", "video"))) continue;
            VideoItem v = new VideoItem();
            v.id = id;
            v.title = HttpJson.firstString(o, "title");
            if (v.title.length() == 0) v.title = "Untitled video";
            v.author = HttpJson.firstString(o, "author", "authorName", "uploader", "author_name");
            long seconds = o.optLong("lengthSeconds", o.optLong("length_seconds", o.optLong("length", 0)));
            v.duration = duration(seconds > Integer.MAX_VALUE ? 0 : (int) seconds);
            v.thumbnail = thumb(o.optJSONArray("videoThumbnails"));
            if (v.thumbnail.length() == 0) v.thumbnail = HttpJson.firstString(o, "thumbnail", "thumbnailUrl", "thumbnail_url");
            v.thumbnail = HttpJson.resolveUrl(base, v.thumbnail);
            v.provider = getName() + " (" + base + ")";
            boolean duplicate = false;
            for (VideoItem existing : out) {
                if (existing.id.equals(v.id)) { duplicate = true; break; }
            }
            if (!duplicate) out.add(v);
        }
        return out;
    }

    private static boolean validVideoId(String id) {
        return id != null && id.matches("[A-Za-z0-9_-]{6,20}");
    }

    public List<StreamItem> streams(String videoId) throws Exception {
        JSONObject o = HttpJson.object(HttpJson.get(base + "/api/v1/videos/" + HttpJson.enc(videoId), 2500, 3500));
        List<StreamItem> out = new ArrayList<StreamItem>();
        // formatStreams are complete/muxed files. adaptiveFormats often contains
        // video-only or audio-only tracks; VideoView cannot merge those tracks itself.
        JSONArray formats = o.optJSONArray("formatStreams");
        addFormats(out, formats);
        if (out.size() == 0) throw new Exception("This instance returned no compatible muxed direct streams");
        return out;
    }

    private void addFormats(List<StreamItem> out, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject f = a.optJSONObject(i);
            if (f == null) continue;
            String url = f.optString("url", "");
            if (url.length() == 0) continue;
            String q = HttpJson.firstString(f, "qualityLabel", "quality", "resolution");
            String mime = HttpJson.firstString(f, "type", "mimeType");
            int h = parseHeight(q);
            String label = (q.length() > 0 ? q : "Available stream") + (mime.length() > 0 ? " · " + mime.split(";")[0] : "");
            out.add(new StreamItem(label, url, mime, h));
        }
    }

    private String thumb(JSONArray a) {
        if (a == null) return "";
        String fallback = "";
        for (int i = 0; i < a.length(); i++) {
            JSONObject t = a.optJSONObject(i);
            if (t == null) continue;
            String url = t.optString("url", "");
            if (url.length() == 0) continue;
            fallback = url;
            String q = t.optString("quality", "");
            if ("medium".equals(q) || "mediumQuality".equals(q) || "default".equals(q)) return url;
        }
        return fallback;
    }

    private static int parseHeight(String q) {
        if (q == null) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3,4})p").matcher(q);
        if (m.find()) try { return Integer.parseInt(m.group(1)); } catch (Exception e) {}
        return 0;
    }
    private static String duration(int s) {
        if (s <= 0) return "";
        return String.format("%d:%02d", s / 60, s % 60);
    }
    private static String trim(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
