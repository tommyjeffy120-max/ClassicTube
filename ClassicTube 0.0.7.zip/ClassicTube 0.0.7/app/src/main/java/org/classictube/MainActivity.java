package org.classictube;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText query;
    private Button searchButton;
    private Button providerSettingsButton;
    private LinearLayout suggestionsBox;
    private TextView status;
    private ListView list;
    private ProgressBar progress;
    private VideoAdapter adapter;
    private final ArrayList<VideoItem> videos = new ArrayList<VideoItem>();
    private final Handler handler = new Handler();
    private Runnable pendingSuggestion;
    private volatile int suggestionGeneration = 0;
    private volatile boolean searching = false;
    private volatile boolean alive = true;
    private List<Provider> providers;
    private final ArrayList<StreamItem> lastStreams = new ArrayList<StreamItem>();
    private VideoItem selectedVideo;

    private static final String PREFS = "classictube";
    private static final String PREF_PREFERRED_YT2009 = "preferred_yt2009";
    private static final String PREF_LAST_GOOD_YT2009 = "last_good_yt2009";
    // The maintained Invidious instance list currently marks this as API-enabled.
    // Other API-enabled instances are discovered from api.invidious.io when reachable.
    private static final String DEFAULT_INVIDIOUS = "https://invidious.f5.si";
    // Prefer alternative Piped servers before the instances that failed on recent tests.
    // These are community instances; none is guaranteed to stay online or accept every client.
    private static final String DEFAULT_PIPED =
        "https://piped-api.privacy.com.de,https://pipedapi.adminforge.de,https://api.piped.yt,https://pipedapi.drgns.space,https://pipedapi.owo.si,https://pipedapi.ducks.party,https://piped-api.codespace.cz,https://pipedapi.reallyaweso.me,https://api.piped.private.coffee,https://pipedapi.darkness.services,https://pipedapi.orangenet.cc,https://pipedapi-libre.kavin.rocks,https://pipedapi.leptons.xyz,https://pipedapi.kavin.rocks,https://pipedapi.nosebs.ru";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        buildUi();
        providers = buildProviders(new NotPipeRegistry.Data());
        adapter = new VideoAdapter(this, videos);
        list.setAdapter(adapter);
        status.setText("Search videos to begin. Playback prioritizes yt2009; configure a preferred instance with Sources.");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 245, 245));
        root.setPadding(8, 6, 8, 4);

        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setBackgroundColor(Color.rgb(190, 25, 35));
        TextView title = new TextView(this);
        title.setText("ClassicTube");
        title.setTextSize(23);
        title.setTextColor(Color.WHITE);
        title.setPadding(10, 10, 8, 10);
        titleBar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        providerSettingsButton = new Button(this);
        providerSettingsButton.setText("Sources");
        providerSettingsButton.setTextSize(12);
        providerSettingsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showSourceSettings(); }
        });
        titleBar.addView(providerSettingsButton, new LinearLayout.LayoutParams(-2, 44));
        root.addView(titleBar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        query = new EditText(this);
        query.setSingleLine(true);
        query.setTextSize(16);
        query.setHint("Search videos...");
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchRow.addView(query, new LinearLayout.LayoutParams(0, 48, 1));
        searchButton = new Button(this);
        searchButton.setText("Search");
        searchRow.addView(searchButton, new LinearLayout.LayoutParams(-2, 48));
        root.addView(searchRow, new LinearLayout.LayoutParams(-1, -2));

        suggestionsBox = new LinearLayout(this);
        suggestionsBox.setOrientation(LinearLayout.VERTICAL);
        suggestionsBox.setPadding(4, 0, 4, 2);
        suggestionsBox.setBackgroundColor(Color.WHITE);
        suggestionsBox.setVisibility(View.GONE);
        root.addView(suggestionsBox, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-2, -2));

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(4, 5, 4, 5);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        list = new ListView(this);
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        String version = BuildConfig.VERSION_NAME;
        if (version.endsWith("-alpha")) version = version.substring(0, version.length() - 6) + " Alpha";
        footer.setText("ClassicTube " + version);
        footer.setTextSize(11);
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(4, 7, 4, 6);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        searchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doSearch(); }
        });
        query.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    doSearch(); return true;
                }
                return false;
            }
        });
        query.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                scheduleSuggestions(s == null ? "" : s.toString().trim());
            }
            public void afterTextChanged(Editable e) {}
        });
        list.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < videos.size()) showPlaybackOptions(videos.get(position));
            }
        });
    }

    private void showSourceSettings() {
        final SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 8, 18, 0);

        TextView note = new TextView(this);
        note.setText("Preferred yt2009 instance (optional). Paste the base URL only, e.g. https://your-instance.example. This is tried first; the discovered instance list remains available as fallback.");
        note.setTextSize(13);
        note.setTextColor(Color.DKGRAY);
        panel.addView(note, new LinearLayout.LayoutParams(-1, -2));

        final EditText preferred = new EditText(this);
        preferred.setSingleLine(true);
        preferred.setTextSize(14);
        preferred.setHint("https://instance.example");
        String savedPreferred = prefs.getString(PREF_PREFERRED_YT2009, "");
        if (savedPreferred.length() == 0) savedPreferred = prefs.getString(PREF_LAST_GOOD_YT2009, "");
        preferred.setText(savedPreferred);
        panel.addView(preferred, new LinearLayout.LayoutParams(-1, -2));

        final AlertDialog sourceDialog = new AlertDialog.Builder(this)
            .setTitle("Playback sources")
            .setView(panel)
            .create();
        sourceDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Save", (android.content.DialogInterface.OnClickListener) null);
        sourceDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel", (android.content.DialogInterface.OnClickListener) null);
        sourceDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Clear", (android.content.DialogInterface.OnClickListener) null);
        sourceDialog.show();
        sourceDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String value = preferred.getText().toString().trim();
                if (value.length() > 0) {
                    while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
                    try {
                        URL parsed = new URL(value);
                        if (!("http".equalsIgnoreCase(parsed.getProtocol()) || "https".equalsIgnoreCase(parsed.getProtocol())) || parsed.getHost().length() == 0 || value.indexOf(',') >= 0 || value.indexOf(' ') >= 0) throw new Exception("invalid URL");
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Enter one complete http:// or https:// base URL, without a trailing path or comma.", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                prefs.edit().putString(PREF_PREFERRED_YT2009, value).commit();
                providers = buildProviders(new NotPipeRegistry.Data());
                Toast.makeText(MainActivity.this, value.length() == 0 ? "Preferred instance cleared. Automatic discovery will be used." : "Preferred yt2009 instance saved. Search again to apply it.", Toast.LENGTH_LONG).show();
                sourceDialog.dismiss();
            }
        });
        sourceDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sourceDialog.dismiss(); }
        });
        sourceDialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                prefs.edit().remove(PREF_PREFERRED_YT2009).remove(PREF_LAST_GOOD_YT2009).commit();
                providers = buildProviders(new NotPipeRegistry.Data());
                Toast.makeText(MainActivity.this, "Saved instance preference cleared.", Toast.LENGTH_SHORT).show();
                sourceDialog.dismiss();
            }
        });
    }

    private void scheduleSuggestions(final String text) {
        if (pendingSuggestion != null) handler.removeCallbacks(pendingSuggestion);
        final int generation = ++suggestionGeneration;
        hideSuggestions();
        if (searching || text.length() < 2 || !alive) return;
        pendingSuggestion = new Runnable() {
            public void run() { fetchSuggestions(text, generation); }
        };
        handler.postDelayed(pendingSuggestion, 420L);
    }

    private void hideSuggestions() {
        if (suggestionsBox != null) {
            suggestionsBox.removeAllViews();
            suggestionsBox.setVisibility(View.GONE);
        }
    }

    private void cancelSuggestions() {
        suggestionGeneration++;
        if (pendingSuggestion != null) handler.removeCallbacks(pendingSuggestion);
        pendingSuggestion = null;
        hideSuggestions();
    }

    private void fetchSuggestions(final String text, final int generation) {
        if (providers == null || text.length() < 2) return;
        final ArrayList<SuggestionProvider> candidates = new ArrayList<SuggestionProvider>();
        int invidiousCount = 0;
        int pipedCount = 0;
        for (Provider provider : providers) {
            if (!(provider instanceof SuggestionProvider)) continue;
            if (provider instanceof InvidiousProvider && invidiousCount < 2) {
                candidates.add((SuggestionProvider) provider);
                invidiousCount++;
            } else if (provider instanceof PipedProvider && pipedCount < 2) {
                candidates.add((SuggestionProvider) provider);
                pipedCount++;
            }
        }
        if (candidates.size() == 0) return;
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<String> merged = new ArrayList<String>();
                ExecutorService executor = Executors.newFixedThreadPool(Math.min(4, candidates.size()));
                CompletionService<List<String>> completion = new ExecutorCompletionService<List<String>>(executor);
                ArrayList<Future<List<String>>> futures = new ArrayList<Future<List<String>>>();
                for (final SuggestionProvider provider : candidates) {
                    futures.add(completion.submit(new Callable<List<String>>() {
                        public List<String> call() throws Exception { return provider.suggestions(text); }
                    }));
                }
                long deadline = System.currentTimeMillis() + 2300L;
                int completed = 0;
                try {
                    while (completed < futures.size() && merged.size() < 6) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (remaining <= 0) break;
                        Future<List<String>> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        try {
                            List<String> items = future.get();
                            if (items != null) {
                                for (String item : items) {
                                    String clean = item == null ? "" : item.trim();
                                    if (clean.length() > 0 && !clean.equalsIgnoreCase(text) && !merged.contains(clean)) merged.add(clean);
                                    if (merged.size() >= 6) break;
                                }
                            }
                        } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {
                } finally {
                    for (Future<List<String>> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                handler.post(new Runnable() {
                    public void run() {
                        if (!alive || generation != suggestionGeneration || searching) return;
                        if (!text.equals(query.getText().toString().trim())) return;
                        showSuggestions(merged);
                    }
                });
            }
        }).start();
    }

    private void showSuggestions(List<String> values) {
        hideSuggestions();
        if (values == null || values.size() == 0 || searching) return;
        TextView heading = new TextView(this);
        heading.setText("Search suggestions");
        heading.setTextSize(11);
        heading.setTextColor(Color.GRAY);
        heading.setPadding(8, 5, 8, 3);
        suggestionsBox.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        for (final String value : values) {
            TextView row = new TextView(this);
            row.setText("⌕  " + value);
            row.setTextSize(14);
            row.setTextColor(Color.DKGRAY);
            row.setPadding(10, 8, 10, 8);
            row.setBackgroundColor(Color.WHITE);
            row.setClickable(true);
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    query.setText(value);
                    query.setSelection(query.length());
                    cancelSuggestions();
                    doSearch();
                }
            });
            suggestionsBox.addView(row, new LinearLayout.LayoutParams(-1, -2));
            View divider = new View(this);
            divider.setBackgroundColor(Color.rgb(232, 232, 232));
            suggestionsBox.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        }
        suggestionsBox.setVisibility(View.VISIBLE);
    }

    private List<Provider> buildProviders(NotPipeRegistry.Data registry) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String inv = p.getString("invidious", DEFAULT_INVIDIOUS);
        String piped = p.getString("piped", DEFAULT_PIPED);
        ArrayList<Provider> out = new ArrayList<Provider>();

        // Use YtAPILegacy only when a live registry supplies an instance. The old
        // hard-coded IP fallback has been refusing connections and made every search
        // report a guaranteed provider failure when the registry was unavailable.
        ArrayList<String> yta = new ArrayList<String>();
        if (registry != null) yta.addAll(registry.ytApiLegacy);
        for (String b : yta) out.add(new YtApiLegacyProvider(b));

        String[] invs = inv.split(",");
        for (int i = 0; i < invs.length; i++) {
            String b = invs[i].trim();
            if (b.length() > 0) out.add(new InvidiousProvider(b));
        }
        // Use only API-enabled HTTPS Invidious entries from the maintained status feed.
        // Do not mix in the older notPipe entries, which may have the JSON API disabled.
        if (registry != null) {
            for (String b : registry.apiEnabledInvidious) {
                if (!containsProvider(out, "Invidious", b)) out.add(new InvidiousProvider(b));
            }
        }

        String[] pipes = piped.split(",");
        for (int i = 0; i < pipes.length; i++) {
            String b = pipes[i].trim();
            if (b.length() > 0 && !containsProvider(out, "Piped", b)) out.add(new PipedProvider(b));
        }
        // A previously verified yt2009 base survives a failed registry refresh. The optional
        // user-pinned base is first, then the last successfully played base, then registry entries.
        ArrayList<String> ytBases = new ArrayList<String>();
        addUnique(ytBases, normalizeBase(p.getString(PREF_PREFERRED_YT2009, "")));
        addUnique(ytBases, normalizeBase(p.getString(PREF_LAST_GOOD_YT2009, "")));
        if (registry != null) {
            for (String b : registry.yt2009) addUnique(ytBases, normalizeBase(b));
            for (String b : registry.piped) {
                if (!containsProvider(out, "Piped", b)) out.add(new PipedProvider(b));
            }
        }
        for (String b : ytBases) {
            if (b.length() > 0 && !containsProvider(out, "yt2009", b)) out.add(new Yt2009Provider(b));
        }
        // Remember and prioritize a provider that actually returned search results before.
        // This prevents each search from repeatedly starting with a server that is known to fail.
        promoteRememberedProvider(out, "Invidious");
        promoteRememberedProvider(out, "Piped");
        promoteRememberedProvider(out, "YtAPILegacy");
        return out;
    }

    private void promoteRememberedProvider(List<Provider> values, String type) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String preferred = prefs.getString("last_good_" + type, "");
        if (preferred.length() == 0) return;
        int match = -1;
        for (int i = 0; i < values.size(); i++) {
            Provider candidate = values.get(i);
            if (!candidate.getName().equals(type)) continue;
            if (providerBase(candidate).equals(preferred)) { match = i; break; }
        }
        if (match < 0) return;
        Provider p = values.remove(match);
        int first = values.size();
        for (int i = 0; i < values.size(); i++) {
            if (values.get(i).getName().equals(type)) { first = i; break; }
        }
        values.add(first, p);
    }

    private static String providerBase(Provider provider) {
        if (provider instanceof InvidiousProvider) return ((InvidiousProvider) provider).getBase();
        if (provider instanceof PipedProvider) return ((PipedProvider) provider).getBase();
        if (provider instanceof Yt2009Provider) return ((Yt2009Provider) provider).getBase();
        if (provider instanceof YtApiLegacyProvider) return ((YtApiLegacyProvider) provider).getBase();
        return "";
    }

    private void rememberSuccessfulProvider(Provider provider) {
        if (provider == null) return;
        String type = provider.getName();
        if (!("Invidious".equals(type) || "Piped".equals(type) || "YtAPILegacy".equals(type))) return;
        String base = providerBase(provider);
        if (base.length() == 0) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("last_good_" + type, base).commit();
    }

    private static void addUnique(List<String> values, String value) {
        if (value != null && value.length() > 0 && !values.contains(value)) values.add(value);
    }

    private static String normalizeBase(String value) {
        if (value == null) return "";
        String b = value.trim();
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        if (!HttpJson.isHttpUrl(b) || b.indexOf(' ') >= 0) return "";
        return b;
    }

    private static boolean containsProvider(List<Provider> values, String name, String base) {
        for (Provider p : values) {
            // getName is provider type only; the exact base is retained in the instance label below.
            if (p.getName().equals(name)) {
                String baseValue = "";
                if (p instanceof InvidiousProvider) baseValue = ((InvidiousProvider) p).getBase();
                else if (p instanceof PipedProvider) baseValue = ((PipedProvider) p).getBase();
                else if (p instanceof Yt2009Provider) baseValue = ((Yt2009Provider) p).getBase();
                if (baseValue.equals(base)) return true;
            }
        }
        return false;
    }

    private void doSearch() {
        final String q = query.getText().toString().trim();
        if (q.length() == 0) {
            Toast.makeText(this, "Enter a search term", Toast.LENGTH_SHORT).show();
            return;
        }
        if (searching) return;
        cancelSuggestions();
        searching = true;
        searchButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Searching available providers...");
        videos.clear();
        adapter.notifyDataSetChanged();

        new Thread(new Runnable() {
            public void run() {
                final ArrayList<VideoItem> results = new ArrayList<VideoItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                NotPipeRegistry.Data registry = NotPipeRegistry.fetch(MainActivity.this);
                final List<Provider> allProviders = buildProviders(registry);
                providers = allProviders;
                final List<Provider> searchList = chooseSearchProviders(allProviders);
                ExecutorService executor = Executors.newFixedThreadPool(Math.min(6, Math.max(1, searchList.size())));
                CompletionService<SearchOutcome> completion = new ExecutorCompletionService<SearchOutcome>(executor);
                ArrayList<Future<SearchOutcome>> futures = new ArrayList<Future<SearchOutcome>>();
                for (final Provider provider : searchList) {
                    futures.add(completion.submit(new Callable<SearchOutcome>() {
                        public SearchOutcome call() {
                            SearchOutcome outcome = new SearchOutcome();
                            outcome.provider = provider.getName();
                            try {
                                outcome.items = provider.search(q);
                                if (outcome.items != null && outcome.items.size() > 0) rememberSuccessfulProvider(provider);
                            } catch (Exception e) {
                                outcome.error = providerLabel(provider) + ": " + safeMessage(e);
                            }
                            return outcome;
                        }
                    }));
                }
                long deadline = System.currentTimeMillis() + 21000L;
                int completed = 0;
                try {
                    while (completed < futures.size() && results.size() < 10) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (remaining <= 0) break;
                        Future<SearchOutcome> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        SearchOutcome outcome = future.get();
                        if (outcome.error != null) errors.add(outcome.error);
                        if (outcome.items != null) {
                            for (VideoItem v : outcome.items) {
                                boolean duplicate = false;
                                for (VideoItem existing : results) {
                                    if (existing.id.equals(v.id)) { duplicate = true; break; }
                                }
                                if (!duplicate) results.add(v);
                                if (results.size() >= 15) break;
                            }
                        }
                    }
                } catch (Exception e) {
                    errors.add("Search: " + safeMessage(e));
                } finally {
                    for (Future<SearchOutcome> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                final int completedProviderCount = completed;
                final int totalProviderCount = futures.size();
                final boolean providerWindowExpired = completed < futures.size();
                handler.post(new Runnable() {
                    public void run() {
                        searching = false;
                        searchButton.setEnabled(true);
                        progress.setVisibility(View.GONE);
                        videos.clear();
                        videos.addAll(results);
                        adapter.notifyDataSetChanged();
                        if (results.size() > 0) {
                            status.setText(results.size() + " results. " + errors.size() + " provider(s) failed or returned no usable results. Playback tries yt2009 first when available; tap a video to continue.");
                        } else {
                            StringBuilder message = new StringBuilder();
                            message.append("Search failed. Checked ").append(completedProviderCount)
                                .append("/").append(totalProviderCount).append(" provider responses");
                            if (providerWindowExpired) message.append(" before the fallback time limit");
                            if (errors.size() > 0) {
                                message.append(". ").append(errors.size()).append(" provider(s) returned errors.");
                                int shown = Math.min(4, errors.size());
                                message.append("\nFirst errors:");
                                for (int i = 0; i < shown; i++) message.append("\n").append(errors.get(i));
                            } else {
                                message.append(". No provider returned a response before the deadline.");
                            }
                            status.setText(message.toString());
                            Toast.makeText(MainActivity.this, "Search failed across available providers. See details on screen.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    /** Include every searchable instance, interleaving backend types for graceful failover. */
    private List<Provider> chooseSearchProviders(List<Provider> all) {
        ArrayList<Provider> selected = new ArrayList<Provider>();
        String[] types = new String[] {"YtAPILegacy", "Invidious", "Piped"};
        int maxPerType = 0;
        for (int t = 0; t < types.length; t++) {
            int count = 0;
            for (Provider p : all) if (p.getName().equals(types[t])) count++;
            if (count > maxPerType) maxPerType = count;
        }
        for (int round = 0; round < maxPerType; round++) {
            for (int t = 0; t < types.length; t++) {
                int found = 0;
                for (Provider p : all) {
                    if (!p.getName().equals(types[t])) continue;
                    found++;
                    if (found == round + 1) { selected.add(p); break; }
                }
            }
        }
        return selected;
    }

    private static String providerLabel(Provider provider) {
        String base = "";
        if (provider instanceof InvidiousProvider) base = ((InvidiousProvider) provider).getBase();
        else if (provider instanceof PipedProvider) base = ((PipedProvider) provider).getBase();
        else if (provider instanceof Yt2009Provider) base = ((Yt2009Provider) provider).getBase();
        else if (provider instanceof YtApiLegacyProvider) base = ((YtApiLegacyProvider) provider).getBase();
        if (base.length() == 0) return provider.getName();
        try { return provider.getName() + " [" + new URL(base).getHost() + "]"; }
        catch (Exception ignored) { return provider.getName() + " [" + base + "]"; }
    }

    private static class SearchOutcome {
        List<VideoItem> items;
        String error;
        String provider;
    }

    private void showPlaybackOptions(final VideoItem video) {
        selectedVideo = video;
        status.setText("Finding a playable stream...");
        progress.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<StreamItem> found = new ArrayList<StreamItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                final List<Provider> candidates = choosePlaybackProviders(providers);
                boolean hasYt2009Candidate = false;
                for (Provider candidate : candidates) if ("yt2009".equals(candidate.getName())) { hasYt2009Candidate = true; break; }
                ExecutorService executor = Executors.newFixedThreadPool(4);
                CompletionService<StreamOutcome> completion = new ExecutorCompletionService<StreamOutcome>(executor);
                ArrayList<Future<StreamOutcome>> futures = new ArrayList<Future<StreamOutcome>>();
                for (final Provider provider : candidates) {
                    futures.add(completion.submit(new Callable<StreamOutcome>() {
                        public StreamOutcome call() {
                            StreamOutcome outcome = new StreamOutcome();
                            outcome.provider = provider.getName();
                            outcome.source = provider;
                            try { outcome.items = provider.streams(video.id); }
                            catch (Exception e) { outcome.error = providerLabel(provider) + ": " + safeMessage(e); }
                            return outcome;
                        }
                    }));
                }
                long deadline = System.currentTimeMillis() + 9000L;
                long yt2009ReadyAt = 0L;
                int completed = 0;
                int successfulBackends = 0;
                try {
                    while (completed < futures.size()) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (yt2009ReadyAt > 0L) remaining = Math.min(remaining, 900L - (System.currentTimeMillis() - yt2009ReadyAt));
                        if (remaining <= 0) break;
                        Future<StreamOutcome> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        StreamOutcome outcome = future.get();
                        if (outcome.error != null) errors.add(outcome.error);
                        if (outcome.items != null && outcome.items.size() > 0) {
                            successfulBackends++;
                            for (StreamItem stream : outcome.items) {
                                if (HttpJson.isHttpUrl(stream.url)) {
                                    String label = stream.label == null ? "Available stream" : stream.label;
                                    label = compactStreamLabel(outcome.provider, label);
                                    String display = providerLabel(outcome.source) + " · " + label;
                                    boolean duplicateUrl = false;
                                    for (StreamItem existing : found) if (stream.url.equals(existing.url)) { duplicateUrl = true; break; }
                                    if (duplicateUrl) continue;
                                    StreamItem available = new StreamItem(display, stream.url, stream.mimeType, stream.height);
                                    if (outcome.source != null) {
                                        available.providerName = outcome.source.getName();
                                        available.providerBase = providerBase(outcome.source);
                                    }
                                    found.add(available);
                                }
                            }
                            if ("yt2009".equals(outcome.provider) && yt2009ReadyAt == 0L) yt2009ReadyAt = System.currentTimeMillis();
                        }
                        // yt2009 is the known-good route: give other backends a short chance,
                        // then stop waiting on slow public instances.
                        if (yt2009ReadyAt > 0L && System.currentTimeMillis() - yt2009ReadyAt >= 900L) break;
                        if (!hasYt2009Candidate && successfulBackends >= 2 && found.size() >= 2) break;
                        if (successfulBackends >= 1 && completed >= futures.size()) break;
                    }
                } catch (Exception e) {
                    errors.add("Playback: " + safeMessage(e));
                } finally {
                    for (Future<StreamOutcome> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                handler.post(new Runnable() {
                    public void run() {
                        progress.setVisibility(View.GONE);
                        if (found.size() == 0) {
                            new AlertDialog.Builder(MainActivity.this)
                                .setTitle("No direct stream available")
                                .setMessage("The available providers did not return a stream quickly enough. This may be a dead instance, an expired link, or a format unsupported by this device. Try another video or retry later.")
                                .setPositiveButton("Open video page", new android.content.DialogInterface.OnClickListener() {
                                    public void onClick(android.content.DialogInterface d, int w) { openVideoPage(video); }
                                })
                                .setNegativeButton("Cancel", null).show();
                            status.setText("No playable stream found. Try another provider or video.");
                        } else {
                            Collections.sort(found, new Comparator<StreamItem>() {
                                public int compare(StreamItem a, StreamItem b) {
                                    int ap = playbackPriority(a.providerName);
                                    int bp = playbackPriority(b.providerName);
                                    if (ap != bp) return ap - bp;
                                    int ah = a.height > 0 ? Math.abs(a.height - 360) : 10000;
                                    int bh = b.height > 0 ? Math.abs(b.height - 360) : 10000;
                                    if (ah != bh) return ah - bh;
                                    int ai = providerInstancePriority(a.providerName, a.providerBase);
                                    int bi = providerInstancePriority(b.providerName, b.providerBase);
                                    if (ai != bi) return ai - bi;
                                    return String.valueOf(a.label).compareToIgnoreCase(String.valueOf(b.label));
                                }
                            });
                            showStreamChooser(video, found);
                        }
                    }
                });
            }
        }).start();
    }

    private static String compactStreamLabel(String providerName, String label) {
        if (label == null) return "Available stream";
        String out = label.trim();
        if (providerName == null) return out;
        String suffix = " · " + providerName;
        if (out.toLowerCase(java.util.Locale.US).endsWith(suffix.toLowerCase(java.util.Locale.US))) {
            out = out.substring(0, out.length() - suffix.length()).trim();
        }
        String prefix = providerName + " · ";
        if (out.toLowerCase(java.util.Locale.US).startsWith(prefix.toLowerCase(java.util.Locale.US))) {
            out = out.substring(prefix.length()).trim();
        }
        return out.length() == 0 ? "Available stream" : out;
    }

    private List<Provider> choosePlaybackProviders(List<Provider> all) {
        ArrayList<Provider> selected = new ArrayList<Provider>();
        if (all == null) return selected;
        // yt2009 is the only backend confirmed by this project to play reliably.
        // Keep a small experimental pool behind it rather than flooding old phones.
        String[] types = new String[] {"yt2009", "YtAPILegacy", "Invidious", "Piped"};
        int[] limits = new int[] {3, 1, 2, 2};
        for (int round = 0; round < 3; round++) {
            for (int t = 0; t < types.length; t++) {
                if (round >= limits[t]) continue;
                int foundCount = 0;
                for (Provider p : all) {
                    if (!p.getName().equals(types[t])) continue;
                    foundCount++;
                    if (foundCount == round + 1) { selected.add(p); break; }
                }
            }
        }
        return selected;
    }

    private int providerInstancePriority(String providerName, String base) {
        int rank = 0;
        if (providers == null) return 1000;
        for (Provider p : providers) {
            if (!p.getName().equals(providerName)) continue;
            if (providerBase(p).equals(base)) return rank;
            rank++;
        }
        return 1000;
    }

    private static int playbackPriority(String providerName) {
        if ("yt2009".equals(providerName)) return 0;
        if ("YtAPILegacy".equals(providerName)) return 1;
        if ("Invidious".equals(providerName)) return 2;
        if ("Piped".equals(providerName)) return 3;
        return 9;
    }

    private static class StreamOutcome {
        List<StreamItem> items;
        String error;
        String provider;
        Provider source;
    }

    private void showStreamChooser(final VideoItem video, final ArrayList<StreamItem> streams) {
        final ArrayList<StreamItem> choices = new ArrayList<StreamItem>(streams);
        // Put 360p first when offered; otherwise prefer the closest lower quality before higher ones.
        // Keep all returned qualities available so users can choose 480p, 720p, or higher if supported.
        Collections.sort(choices, new Comparator<StreamItem>() {
            public int compare(StreamItem a, StreamItem b) {
                int ap = playbackPriority(a.providerName);
                int bp = playbackPriority(b.providerName);
                if (ap != bp) return ap - bp;
                int ah = a.height > 0 ? Math.abs(a.height - 360) : 10000;
                int bh = b.height > 0 ? Math.abs(b.height - 360) : 10000;
                if (ah != bh) return ah - bh;
                int ai = providerInstancePriority(a.providerName, a.providerBase);
                int bi = providerInstancePriority(b.providerName, b.providerBase);
                if (ai != bi) return ai - bi;
                if (a.height != b.height) return a.height - b.height;
                return String.valueOf(a.label).compareToIgnoreCase(String.valueOf(b.label));
            }
        });
        final String[] labels = new String[choices.size() + 1];
        final String[] urls = new String[choices.size()];
        final String[] mimes = new String[choices.size()];
        final String[] providerNames = new String[choices.size()];
        final String[] providerBases = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            labels[i] = choices.get(i).label;
            if (i == 0 && choices.get(i).height == 360) labels[i] = "Recommended · " + labels[i];
            urls[i] = choices.get(i).url;
            mimes[i] = choices.get(i).mimeType == null ? "video/*" : choices.get(i).mimeType;
            providerNames[i] = choices.get(i).providerName == null ? "" : choices.get(i).providerName;
            providerBases[i] = choices.get(i).providerBase == null ? "" : choices.get(i).providerBase;
        }
        labels[choices.size()] = "Open YouTube video page";
        new AlertDialog.Builder(this).setTitle("Choose quality / source")
            .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dialog, int which) {
                    if (which == choices.size()) { openVideoPage(video); return; }
                    StreamItem stream = choices.get(which);
                    Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                    intent.putExtra(PlayerActivity.EXTRA_TITLE, video.title);
                    intent.putExtra(PlayerActivity.EXTRA_VIDEO_ID, video.id);
                    intent.putExtra(PlayerActivity.EXTRA_URLS, urls);
                    intent.putExtra(PlayerActivity.EXTRA_LABELS, labelsForChoices(choices));
                    intent.putExtra(PlayerActivity.EXTRA_MIMES, mimes);
                    intent.putExtra(PlayerActivity.EXTRA_PROVIDER_NAMES, providerNames);
                    intent.putExtra(PlayerActivity.EXTRA_PROVIDER_BASES, providerBases);
                    intent.putExtra(PlayerActivity.EXTRA_START_INDEX, which);
                    intent.putExtra(PlayerActivity.EXTRA_URL, stream.url);
                    intent.putExtra(PlayerActivity.EXTRA_MIME, stream.mimeType == null ? "video/*" : stream.mimeType);
                    intent.putExtra(PlayerActivity.EXTRA_LABEL, stream.label == null ? "Video" : stream.label);
                    intent.putExtra(PlayerActivity.EXTRA_RELATED_PROVIDER_NAME, stream.providerName == null ? "" : stream.providerName);
                    intent.putExtra(PlayerActivity.EXTRA_RELATED_PROVIDER_BASE, stream.providerBase == null ? "" : stream.providerBase);
                    intent.putStringArrayListExtra(PlayerActivity.EXTRA_RELATED_SOURCES, buildRelatedProviderSources(stream.providerName, stream.providerBase));
                    startActivity(intent);
                }
            }).show();
        status.setText("Choose a quality. Playback stays inside ClassicTube.");
    }

    private ArrayList<String> buildRelatedProviderSources(String preferredName, String preferredBase) {
        ArrayList<String> out = new ArrayList<String>();
        int invidious = 0;
        int piped = 0;
        int legacy = 0;
        int yt2009 = 0;
        if (providers == null) return out;
        if (preferredName != null && preferredBase != null &&
            ("Invidious".equals(preferredName) || "Piped".equals(preferredName)) && preferredBase.length() > 0) {
            out.add(preferredName + "|" + preferredBase);
            if ("Invidious".equals(preferredName)) invidious = 1;
            else piped = 1;
        }
        for (Provider provider : providers) {
            String type = provider.getName();
            int count = 0;
            if ("Invidious".equals(type)) count = ++invidious;
            else if ("Piped".equals(type)) count = ++piped;
            else if ("YtAPILegacy".equals(type)) count = ++legacy;
            else if ("yt2009".equals(type)) count = ++yt2009;
            else continue;
            if (("Invidious".equals(type) && count > 4) ||
                ("Piped".equals(type) && count > 4) ||
                ("YtAPILegacy".equals(type) && count > 1) ||
                ("yt2009".equals(type) && count > 3)) continue;
            String base = providerBase(provider);
            if (preferredName != null && preferredBase != null && type.equals(preferredName) && base.equals(preferredBase)) continue;
            if (base.length() > 0) out.add(type + "|" + base);
        }
        return out;
    }

    private String[] labelsForChoices(ArrayList<StreamItem> choices) {
        String[] out = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) out[i] = choices.get(i).label == null ? "Video stream" : choices.get(i).label;
        return out;
    }

    private void openVideoPage(VideoItem v) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + v.id));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No browser is available to open this video.", Toast.LENGTH_LONG).show();
        }
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null ? "request failed" : m;
    }

    private class VideoAdapter extends BaseAdapter {
        private final Context context;
        private final List<VideoItem> items;
        VideoAdapter(Context c, List<VideoItem> list) { context = c; items = list; }
        public int getCount() { return items.size(); }
        public Object getItem(int p) { return items.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int position, View convert, ViewGroup parent) {
            final VideoItem item = items.get(position);
            LinearLayout row;
            ImageView image;
            LinearLayout textCol;
            TextView title;
            TextView meta;
            if (convert instanceof LinearLayout) {
                row = (LinearLayout) convert;
                image = (ImageView) row.getChildAt(0);
                textCol = (LinearLayout) row.getChildAt(1);
                title = (TextView) textCol.getChildAt(0);
                meta = (TextView) textCol.getChildAt(1);
            } else {
                row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(3, 7, 3, 7);
                image = new ImageView(context);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(Color.LTGRAY);
                row.addView(image, new LinearLayout.LayoutParams(112, 72));
                textCol = new LinearLayout(context);
                textCol.setOrientation(LinearLayout.VERTICAL);
                textCol.setPadding(9, 1, 2, 1);
                row.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1));
                title = new TextView(context);
                title.setTextSize(15);
                title.setTextColor(Color.BLACK);
                textCol.addView(title);
                meta = new TextView(context);
                meta.setTextSize(12);
                meta.setTextColor(Color.DKGRAY);
                textCol.addView(meta);
            }
            title.setText(item.title);
            String m = item.author;
            if (item.duration.length() > 0) m += (m.length() > 0 ? " • " : "") + item.duration;
            meta.setText(m);
            image.setImageDrawable(null);
            image.setTag("video:" + item.id);
            loadThumbnail(image, item.thumbnail, item.id);
            return row;
        }
    }

    private void loadThumbnail(final ImageView target, final String address, final String videoId) {
        final String expectedTag = "video:" + videoId;
        new Thread(new Runnable() {
            public void run() {
                Bitmap bmp = null;
                String[] candidates = new String[] {
                    address,
                    "https://i.ytimg.com/vi/" + videoId + "/mqdefault.jpg",
                    "https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg"
                };
                for (int i = 0; i < candidates.length && bmp == null; i++) {
                    String candidate = candidates[i];
                    if (!HttpJson.isHttpUrl(candidate)) continue;
                    boolean seen = false;
                    for (int j = 0; j < i; j++) if (candidate.equals(candidates[j])) seen = true;
                    if (seen) continue;
                    HttpURLConnection c = null;
                    InputStream in = null;
                    try {
                        c = (HttpURLConnection) new URL(candidate).openConnection();
                        c.setConnectTimeout(2200);
                        c.setReadTimeout(2800);
                        c.setInstanceFollowRedirects(true);
                        c.setRequestProperty("User-Agent", "ClassicTube/0.3 (Android video client)");
                        c.setRequestProperty("Accept", "image/*,*/*;q=0.8");
                        int code = c.getResponseCode();
                        if (code < 200 || code >= 300) continue;
                        in = c.getInputStream();
                        BitmapFactory.Options opt = new BitmapFactory.Options();
                        opt.inSampleSize = 2;
                        bmp = BitmapFactory.decodeStream(in, null, opt);
                    } catch (Exception ignored) {
                    } finally {
                        try { if (in != null) in.close(); } catch (Exception ignored) {}
                        if (c != null) c.disconnect();
                    }
                }
                final Bitmap finalBitmap = bmp;
                if (finalBitmap != null) handler.post(new Runnable() {
                    public void run() {
                        if (expectedTag.equals(target.getTag())) target.setImageBitmap(finalBitmap);
                        else finalBitmap.recycle();
                    }
                });
            }
        }).start();
    }

    @Override protected void onDestroy() {
        alive = false;
        super.onDestroy();
    }
}
