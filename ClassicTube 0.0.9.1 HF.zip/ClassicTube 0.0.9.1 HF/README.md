## 0.0.7.3 Alpha — Android 4.4 fullscreen compatibility hotfix

- Uses Android 4.4 immersive-sticky system UI flags to hide the status and navigation bars during fullscreen playback.
- Adds `screenSize` and `smallestScreenSize` configuration handling so the player Activity is not recreated merely because fullscreen changes orientation.
- Applies fullscreen visibility again after configuration changes, window focus changes, and activity resume.
- Saves the active stream URL, MIME type, label, playback position, source index, and fullscreen state if Android still needs to recreate the Activity.
- Changes fullscreen in-place; Back exits fullscreen first instead of unintentionally finishing the player Activity.
- Keeps the existing player view instead of rebuilding it during orientation changes, reducing playback resets on older Android devices.

## 0.0.7.1 Alpha — recommendations reliability hotfix

- Remembers recommendations that have previously loaded and shows them while refreshing.
- Tries up to three distinct Invidious and three Piped instances for recommendations.
- Falls back to title-based search suggestions if recommendation endpoints return no usable list.
- Keeps yt2009 playback behavior unchanged.

# ClassicTube 0.0.7 Alpha — playback reliability revamp

ClassicTube is a lightweight native Java Android YouTube client with an old-school interface. This revamp focuses on making provider failures finite and keeping the known-good yt2009 route ahead of experimental stream APIs.

## What's new in 0.0.7

- **yt2009-first playback ordering.** Playback lookup now prioritizes yt2009 instances and conservative 360p selection before experimental Invidious/Piped/YtAPILegacy stream URLs.
- **Remember a working instance.** Once a yt2009 stream actually reaches Android's `onPrepared` event, ClassicTube remembers that instance and includes it first next time, even if the remote instance registry becomes temporarily unavailable.
- **Optional preferred yt2009 instance.** The new **Sources** button lets the user pin a known yt2009 base URL or clear it to return to automatic discovery.
- **Automatic playback failover.** If Android reports a stream error or a source takes too long to start, ClassicTube tries the next unfailed URL automatically instead of leaving the user to notice an endless spinner.
- **No endless URL cycling.** Each URL is attempted at most once per playback run. Retry explicitly resets the failed list.
- **Per-stream provider tracking.** The player carries each option's provider name and base URL, so related-video lookups and successful-instance memory follow the source actually selected or used by failover.
- **Shorter, bounded waits.** API stream-detail calls use bounded network timeouts, playback waits briefly for secondary sources after yt2009 returns, and HTTP response bodies are capped to prevent a misbehaving instance consuming excessive memory.
- **More useful status text.** Search results now also report how many providers failed or returned no usable results. HTTP errors include a short response preview when available.
- **Keeps the existing product features:** search suggestions, source/quality selector, in-app VideoView player, Android seek controls, retry, next source, external player, fullscreen, and best-effort related videos.

## Provider reliability and important limitations

- The only backend confirmed by this project's real-device reports is yt2009. It is therefore preferred, **not advertised as universally available**.
- Invidious and Piped stay as experimental search/playback/related-video fallbacks. A provider can return a syntactically valid URL that is still blocked, expired, unsupported by Android's decoder, or offline.
- A timeout can trigger another URL, but no client can make an offline instance work. If every stream fails, the player now reports that rather than looping forever.
- Public instances are community-operated and can change or disappear. Do not assume a green/valid host response guarantees the video endpoint works.
- Related recommendations still depend on Invidious/Piped APIs; yt2009 playback itself does not guarantee a related-video API. Recommendation failures do not intentionally stop current playback.
- The default yt2009 registry is still discovered through the existing notPipe feed. If the feed is unavailable before any working host has been remembered, enter a known base URL through **Sources**.
- Android 2.x/old firmware may reject newer TLS certificates or unsupported codecs. ClassicTube does not disable TLS certificate checks.

## Project/version

- Android application ID: `org.classictube`
- Version name: `0.0.7.3-alpha`
- Version code: `13`
- Min SDK remains API 8; target SDK remains 28.
- Source archive only; it does not contain a built APK.

## API references

- Invidious API: https://docs.invidious.io/api/
- Piped API: https://docs.piped.video/docs/api-documentation/
- notPipe upstream instance list/client: https://github.com/gohoski/notPipe
- yt2009 upstream project: https://github.com/CubeFun/yt2009

## Build workflow

Replace the root `ClassicTube Fullscreen Upd.zip` expected by the repository's existing GitHub Actions workflow with this project (preserving that exact archive filename), then run the workflow. Install only after Actions reports that the APK build succeeded. This source ZIP has not been compiled with Android Gradle in this environment.


## 0.0.7.2 Alpha hotfix — related-result playback

- Always includes the currently playing yt2009 host when resolving a tapped related result, even if the instance registry refresh failed or its provider list is stale.
- Includes the user's preferred and last known-good yt2009 hosts in the related-video stream candidate list.
- Tries the backend/host that supplied a related suggestion and preserves that preference when the item is cached.
- Includes the currently active provider and remembered last-good playback source as additional fallbacks, with a bounded maximum of 10 provider attempts.
- Keeps the original video selected if no candidate source URLs can be found; when URLs are found, the existing playback error/timeout failover can move through them.

This source update was structurally checked, but still requires a successful GitHub Actions Android build and device test.


## 0.0.8 Alpha — Responsive search controls

The search field, Search button, and Instances button now occupy a dedicated horizontal row. The title bar no longer competes for the same width, and control heights/padding are sized to reduce clipping on older Android themes and devices with larger font scaling. Version metadata is 0.0.8-alpha (versionCode 14).


## 0.0.9 Alpha — Pioneer

- Expands the related-video list and persistent per-video recommendation cache from 6 to 10 items. Recommendation collection also continues across compatible sources and can top up a short list with title-based search suggestions when available.
- Tapping a related video now resolves eligible streams first and asks the user to choose quality/source before switching. Cancel leaves the current video selected and playing.
- Adds a **Quality** button immediately after **Retry** in the player controls. It lists the currently resolved quality/source choices and changes stream in-place while seeking to the current playback position.
- Version name is `0.0.9-alpha` (versionCode 15). Existing provider order, old-Android immersive fullscreen handling, and player layout remain in place.

This archive has been checked structurally, but must still pass the repository's actual Gradle/GitHub Actions build and device tests before release.


## 0.0.9.1 Alpha — Pioneer provider-discovery hotfix

- Expands stream discovery to up to five Invidious instances and three Piped instances while retaining three yt2009 candidates and one YtAPILegacy candidate.
- Uses a larger bounded discovery window and up to six concurrent provider lookups, so fast yt2009 candidate generation no longer cancels the slower Invidious API requests after only 900 ms.
- Promotes the exact host that actually reached playback, ahead of an instance known only to return search results.
- Shows selected stream count and a short list of real provider errors when no usable stream can be found.
- Version name is `0.0.9.1-alpha` (versionCode 16).

This is a source hotfix. The public Invidious service pool can still contain servers which are offline, rate-limited, or unable to return compatible streams; those instances will be skipped and their failures exposed. A successful Android Gradle build and device retest are still required.
