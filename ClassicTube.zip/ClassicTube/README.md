# ClassicTube 0.3 — in-app player and multi-backend prototype

A lightweight native Java Android client targeting Android 2.2 (API 8). This build adds API adapters based on the public `gohoski/notPipe` project, which supports Invidious, Piped, yt2009, and YtAPILegacy.

## Added in this build

- Built-in player using Android's native `VideoView` and `MediaController`, so playback stays inside ClassicTube. This uses platform APIs compatible with very old Android versions rather than AndroidX Media3 (which would raise the minimum Android level).
- The player displays buffering/error status, supports retry, offers a next-source button, and keeps an external-player fallback.
- Stream discovery checks a small balanced set of providers concurrently, then allows switching between returned stream URLs.
- Search checks a balanced provider sample concurrently with a short overall deadline instead of waiting for many public instances one by one.
- Thumbnails fall back to YouTube's `mqdefault.jpg`/`hqdefault.jpg` when a backend thumbnail fails; thumbnail requests have shorter timeouts.
- A successful notPipe registry response is cached for six hours; dead registry requests have a shorter timeout.



- YtAPILegacy metadata search (`/get_search_videos.php?query=...`) and stream URLs (`/direct_url?video_id=...&quality=...`).
- yt2009 playback adapter using the video endpoints documented/used by notPipe (`/channel_fh264_getvideo`, `/get_480`, `/exp_hd`). yt2009 is playback-only in this adapter because notPipe itself uses it for streaming rather than general search.
- Best-effort runtime fetch/cache of notPipe's instance registry: `http://144.31.189.129/notPipe.json`.
- A fallback YtAPILegacy instance from notPipe's own default config: `http://45.132.96.44:2823`.
- Invidious list updated to currently documented public entries, and Piped search accepts either array results or object results containing `items`, `videos`, or `results`.
- HTTP stream/thumbnail support for the legacy APIs. Cleartext HTTP is enabled because the notPipe registry/default YtAPILegacy source currently use HTTP. Do not add login credentials or secrets to this app.

## Important limitations

This is still a prototype, not a guaranteed working YouTube client. Public instances can go offline, block requests, change JSON formats, or have compatibility problems. In our check while preparing this build, the notPipe instance-list URL refused the connection, so the app will use its cached list if available and otherwise fall back to the configured endpoints. The default YtAPILegacy host may also be offline; it is included because it is the default specified by notPipe's source, not because it was confirmed reachable.

A successful APK build does not prove that every provider is reachable. Test search on your device and note the provider/error message. Android 2.2's old TLS stack can still reject modern HTTPS servers. This app does not disable TLS certificate verification.

## References

- notPipe source and supported APIs: https://github.com/gohoski/notPipe
- notPipe instance feed referenced in its README/config: http://144.31.189.129/notPipe.json
- notPipe YtAPILegacy implementation: https://github.com/gohoski/notPipe/blob/main/app/src/main/java/io/github/gohoski/notpipe/api/YtApiLegacy.java
- notPipe yt2009 implementation: https://github.com/gohoski/notPipe/blob/main/app/src/main/java/io/github/gohoski/notpipe/api/Yt2009.java
- Invidious API docs: https://docs.invidious.io/api/
- Current Invidious public-instance documentation: https://docs.invidious.io/instances/
- Piped API docs: https://docs.piped.video/docs/api-documentation/

## Build

The GitHub Actions workflow in the conversation repository can extract this ZIP and compile a debug APK. This ZIP itself does not include a new APK; build it with the workflow and download the artifact.

## Player limitations

The internal player uses the device's built-in Android media framework. It avoids launching another app, but it cannot repair a dead/expired stream URL, a server that refuses the request, or a codec the device lacks. Use “Next source” for another returned URL and the visible error code to distinguish stream/codec problems. For modern Android, a future optional modern player could improve codec support, but it would not preserve Android 2.2 compatibility if it raised the minimum SDK.
