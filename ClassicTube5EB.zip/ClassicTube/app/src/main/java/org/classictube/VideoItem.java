package org.classictube;

public class VideoItem {
    public String id = "";
    public String title = "";
    public String author = "";
    public String thumbnail = "";
    public String duration = "";
    public String provider = "";

    public String toString() {
        return title + (author.length() > 0 ? "\n" + author : "");
    }
}
