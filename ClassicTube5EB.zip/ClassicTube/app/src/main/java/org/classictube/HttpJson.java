package org.classictube;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public final class HttpJson {
    private HttpJson() {}

    public static String get(String address) throws Exception {
        return get(address, 7000, 9000);
    }

    public static String get(String address, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(connectTimeout);
        c.setReadTimeout(readTimeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "ClassicTube/0.2 (legacy Android client)");
        c.setRequestProperty("Accept", "application/json, */*");
        try {
            int status = c.getResponseCode();
            InputStream in = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) throw new Exception("HTTP " + status);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            in.close();
            String body = new String(out.toByteArray(), "UTF-8");
            if (status < 200 || status >= 300) throw new Exception("HTTP " + status);
            return body;
        } finally {
            c.disconnect();
        }
    }

    public static JSONArray array(String body) throws Exception {
        return new JSONArray(body);
    }

    public static JSONObject object(String body) throws Exception {
        return new JSONObject(body);
    }

    public static String enc(String s) throws Exception {
        return java.net.URLEncoder.encode(s, "UTF-8");
    }

    public static String firstString(JSONObject o, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            String v = o.optString(keys[i], "");
            if (v != null && v.length() > 0 && !"null".equals(v)) return v;
        }
        return "";
    }

    public static String resolveUrl(String base, String value) {
        if (value == null || value.length() == 0 || "null".equals(value)) return "";
        try {
            return new URL(new URL(base.endsWith("/") ? base : base + "/"), value).toString();
        } catch (Exception ignored) {
            return value;
        }
    }

    public static boolean isHttpUrl(String value) {
        return value != null && (value.startsWith("https://") || value.startsWith("http://"));
    }
}
