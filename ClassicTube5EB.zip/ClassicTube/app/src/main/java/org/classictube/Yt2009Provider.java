package org.classictube;

import java.util.ArrayList;
import java.util.List;

/** yt2009 is treated as a playback backend; notPipe does not use it for general search. */
public class Yt2009Provider implements Provider {
    private final String base;
    public Yt2009Provider(String base) { this.base = trim(base); }
    public String getName() { return "yt2009"; }
    public String getBase() { return base; }

    public List<VideoItem> search(String query) throws Exception {
        throw new Exception("yt2009 playback backend has no general search adapter");
    }

    public List<StreamItem> streams(String videoId) throws Exception {
        if (videoId == null || !videoId.matches("[A-Za-z0-9_-]{6,20}")) {
            throw new Exception("Invalid video ID");
        }
        List<StreamItem> out = new ArrayList<StreamItem>();
        out.add(new StreamItem("360p · yt2009", base + "/channel_fh264_getvideo?v=" + videoId, "video/*", 360));
        out.add(new StreamItem("480p · yt2009", base + "/get_480?video_id=" + videoId, "video/*", 480));
        out.add(new StreamItem("720p · yt2009", base + "/exp_hd?video_id=" + videoId, "video/*", 720));
        out.add(new StreamItem("1080p · yt2009", base + "/exp_hd?video_id=" + videoId + "&fhd=1", "video/*", 1080));
        return out;
    }

    private static String trim(String s) {
        if (s == null) return "";
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
