package org.classictube;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;

/** In-app player built from platform APIs available on Android 1.5+ (including API 8). */
public class PlayerActivity extends Activity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_VIDEO_ID = "video_id";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_MIME = "mime";
    public static final String EXTRA_LABEL = "label";
    public static final String EXTRA_URLS = "urls";
    public static final String EXTRA_LABELS = "labels";
    public static final String EXTRA_MIMES = "mimes";
    public static final String EXTRA_START_INDEX = "start_index";

    private LinearLayout rootLayout;
    private LinearLayout headerLayout;
    private LinearLayout buttonsLayout;
    private Button fullscreenButton;
    private boolean fullscreen;
    private int originalRequestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

    private VideoView videoView;
    private ProgressBar spinner;
    private TextView status;
    private TextView titleView;
    private TextView sourceView;
    private String title;
    private String videoId;
    private String[] urls;
    private String[] labels;
    private String[] mimes;
    private int streamIndex;
    private String currentUrl;
    private String currentMime;
    private String currentLabel;
    private boolean prepared;
    private boolean wasPlaying;
    private int savedPosition;
    private MediaController controller;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        originalRequestedOrientation = getRequestedOrientation();
        title = getIntent().getStringExtra(EXTRA_TITLE);
        videoId = getIntent().getStringExtra(EXTRA_VIDEO_ID);
        urls = getIntent().getStringArrayExtra(EXTRA_URLS);
        labels = getIntent().getStringArrayExtra(EXTRA_LABELS);
        mimes = getIntent().getStringArrayExtra(EXTRA_MIMES);
        streamIndex = getIntent().getIntExtra(EXTRA_START_INDEX, 0);
        currentUrl = getIntent().getStringExtra(EXTRA_URL);
        currentMime = getIntent().getStringExtra(EXTRA_MIME);
        currentLabel = getIntent().getStringExtra(EXTRA_LABEL);
        if (title == null) title = "ClassicTube Player";
        if (currentMime == null || currentMime.length() == 0) currentMime = "video/*";
        if (currentLabel == null) currentLabel = "Video stream";
        if (currentUrl == null || currentUrl.length() == 0) {
            Toast.makeText(this, "No video URL was supplied.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildPlayerUi();
        startStream(currentUrl, currentMime, currentLabel, 0);
    }

    private void buildPlayerUi() {
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.rgb(15, 15, 15));

        headerLayout = new LinearLayout(this);
        headerLayout.setOrientation(LinearLayout.VERTICAL);
        headerLayout.setPadding(12, 9, 12, 8);
        headerLayout.setBackgroundColor(Color.rgb(190, 25, 35));
        titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(17);
        headerLayout.addView(titleView, new LinearLayout.LayoutParams(-1, -2));
        sourceView = new TextView(this);
        sourceView.setTextColor(Color.rgb(255, 230, 230));
        sourceView.setTextSize(12);
        sourceView.setText(currentLabel);
        headerLayout.addView(sourceView, new LinearLayout.LayoutParams(-1, -2));
        rootLayout.addView(headerLayout, new LinearLayout.LayoutParams(-1, -2));

        final FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        videoView = new VideoView(this);
        frame.addView(videoView, new FrameLayout.LayoutParams(-1, -1));
        spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        FrameLayout.LayoutParams spinParams = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        frame.addView(spinner, spinParams);
        rootLayout.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(10, 7, 10, 7);
        status.setText("Connecting to stream...");
        rootLayout.addView(status, new LinearLayout.LayoutParams(-1, -2));

        buttonsLayout = new LinearLayout(this);
        buttonsLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonsLayout.setPadding(4, 3, 4, 7);
        Button retry = new Button(this);
        retry.setText("Retry");
        buttonsLayout.addView(retry, new LinearLayout.LayoutParams(0, -2, 1));
        Button next = new Button(this);
        next.setText("Next source");
        next.setTextSize(12);
        next.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(next, new LinearLayout.LayoutParams(0, -2, 1));
        Button external = new Button(this);
        external.setText("External");
        external.setTextSize(12);
        external.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(external, new LinearLayout.LayoutParams(0, -2, 1));
        fullscreenButton = new Button(this);
        fullscreenButton.setText("Fullscreen");
        fullscreenButton.setTextSize(12);
        fullscreenButton.setPadding(0, 0, 0, 0);
        buttonsLayout.addView(fullscreenButton, new LinearLayout.LayoutParams(0, -2, 1));
        rootLayout.addView(buttonsLayout, new LinearLayout.LayoutParams(-1, -2));
        setContentView(rootLayout);

        controller = new MediaController(this);
        videoView.setMediaController(controller);
        controller.setAnchorView(videoView);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                prepared = true;
                spinner.setVisibility(View.GONE);
                status.setText("Playing in ClassicTube. Tap the video for controls.");
                controller.setAnchorView(videoView);
                if (savedPosition > 0) {
                    try { videoView.seekTo(savedPosition); } catch (Exception ignored) {}
                    savedPosition = 0;
                }
                videoView.start();
                wasPlaying = true;
            }
        });
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                spinner.setVisibility(View.GONE);
                status.setText("Playback finished.");
                wasPlaying = false;
            }
        });
        videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                prepared = false;
                wasPlaying = false;
                spinner.setVisibility(View.GONE);
                status.setText("Playback failed (" + what + "/" + extra + "). Try Next source. The stream may be unavailable or its codec unsupported.");
                return true;
            }
        });
        retry.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startStream(currentUrl, currentMime, currentLabel, 0); }
        });
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { playNextSource(); }
        });
        external.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openExternal(); }
        });
        fullscreenButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setFullscreen(true); }
        });
    }

    /** Hide the app chrome and status bar, while keeping Android's navigation bar visible. */
    private void setFullscreen(boolean enabled) {
        if (fullscreen == enabled || rootLayout == null) return;
        fullscreen = enabled;
        if (enabled) {
            headerLayout.setVisibility(View.GONE);
            status.setVisibility(View.GONE);
            buttonsLayout.setVisibility(View.GONE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            // Landscape gives the video more room. The system navigation bar stays visible,
            // so the user can press Back once to return to the normal player layout.
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            Toast.makeText(this, "Fullscreen enabled. Press Back to exit.", Toast.LENGTH_SHORT).show();
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            setRequestedOrientation(originalRequestedOrientation);
            headerLayout.setVisibility(View.VISIBLE);
            status.setVisibility(View.VISIBLE);
            buttonsLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override public void onBackPressed() {
        if (fullscreen) {
            setFullscreen(false);
            return;
        }
        super.onBackPressed();
    }

    private void startStream(String url, String mime, String label, int seekPosition) {
        if (url == null || url.length() == 0) {
            status.setText("This source did not provide a stream URL.");
            spinner.setVisibility(View.GONE);
            return;
        }
        currentUrl = url;
        currentMime = mime == null || mime.length() == 0 ? "video/*" : mime;
        currentLabel = label == null ? "Video stream" : label;
        if (sourceView != null) sourceView.setText(currentLabel);
        if (status != null) status.setText("Connecting to stream...");
        if (spinner != null) spinner.setVisibility(View.VISIBLE);
        prepared = false;
        savedPosition = seekPosition;
        try {
            videoView.stopPlayback();
            videoView.setVideoURI(Uri.parse(currentUrl));
            videoView.requestFocus();
        } catch (Exception e) {
            spinner.setVisibility(View.GONE);
            status.setText("Could not open this stream URL. Try Next source.");
        }
    }

    private void playNextSource() {
        if (urls == null || urls.length == 0) {
            status.setText("No alternate streams were returned. Go back and retry the video.");
            return;
        }
        int attempts = 0;
        int next = streamIndex;
        while (attempts < urls.length) {
            next = (next + 1) % urls.length;
            attempts++;
            if (urls[next] != null && urls[next].length() > 0 && !urls[next].equals(currentUrl)) break;
        }
        if (attempts > urls.length || urls[next] == null || urls[next].length() == 0 || urls[next].equals(currentUrl)) {
            status.setText("No different source is available. Go back and retry the video.");
            return;
        }
        streamIndex = next;
        String label = labels != null && next < labels.length ? labels[next] : "Alternate source";
        String mime = mimes != null && next < mimes.length ? mimes[next] : "video/*";
        startStream(urls[next], mime, label, 0);
    }

    private void openExternal() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(currentUrl), currentMime.split(";")[0]);
            startActivity(intent);
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))); }
            catch (Exception ignored) { Toast.makeText(this, "No compatible external player is installed.", Toast.LENGTH_LONG).show(); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        try {
            if (videoView != null && videoView.isPlaying()) {
                savedPosition = videoView.getCurrentPosition();
                videoView.pause();
                wasPlaying = true;
            }
        } catch (Exception ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (videoView != null && prepared && wasPlaying) {
            try { videoView.seekTo(savedPosition); videoView.start(); }
            catch (Exception ignored) {}
        }
    }

    @Override protected void onDestroy() {
        try { if (videoView != null) videoView.stopPlayback(); } catch (Exception ignored) {}
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
}
