package org.classictube;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Adapter for the YtAPILegacy endpoints used by notPipe.
 * Public instances are community-operated and may be offline at any time.
 */
public class YtApiLegacyProvider implements Provider {
    private final String base;
    public YtApiLegacyProvider(String base) { this.base = trim(base); }
    public String getName() { return "YtAPILegacy"; }

    public List<VideoItem> search(String query) throws Exception {
        String address = base + "/get_search_videos.php?query=" + HttpJson.enc(query);
        JSONArray a = HttpJson.array(HttpJson.get(address, 4500, 6500));
        List<VideoItem> out = new ArrayList<VideoItem>();
        for (int i = 0; i < a.length() && out.size() < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = HttpJson.firstString(o, "video_id", "videoId", "id");
            if (id.length() == 0) continue;
            VideoItem v = new VideoItem();
            v.id = id;
            v.title = HttpJson.firstString(o, "title");
            if (v.title.length() == 0) v.title = "Untitled video";
            v.author = HttpJson.firstString(o, "author", "channel", "uploader");
            v.duration = HttpJson.firstString(o, "duration");
            if (v.duration.length() == 0) {
                try { v.duration = formatDuration(o.optInt("length_seconds", 0)); }
                catch (Exception ignored) {}
            }
            v.thumbnail = HttpJson.resolveUrl(base, HttpJson.firstString(o, "thumbnail", "thumbnail_url"));
            v.provider = getName() + " (" + base + ")";
            out.add(v);
        }
        if (out.size() == 0) throw new Exception("YtAPILegacy returned no video results");
        return out;
    }

    public List<StreamItem> streams(String videoId) throws Exception {
        // notPipe uses /direct_url?video_id=...&quality=... for this backend.
        String id = HttpJson.enc(videoId);
        List<StreamItem> out = new ArrayList<StreamItem>();
        int[] qualities = new int[] {360, 480, 720, 1080};
        for (int i = 0; i < qualities.length; i++) {
            int q = qualities[i];
            String url = base + "/direct_url?video_id=" + id + "&quality=" + q;
            out.add(new StreamItem(q + "p · YtAPILegacy", url, "video/*", q));
        }
        return out;
    }

    private static String formatDuration(int seconds) {
        if (seconds <= 0) return "";
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }

    private static String trim(String s) {
        if (s == null) return "";
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
