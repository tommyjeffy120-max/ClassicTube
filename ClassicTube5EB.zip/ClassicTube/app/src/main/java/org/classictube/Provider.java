package org.classictube;

import java.util.List;

public interface Provider {
    String getName();
    List<VideoItem> search(String query) throws Exception;
    List<StreamItem> streams(String videoId) throws Exception;
}
