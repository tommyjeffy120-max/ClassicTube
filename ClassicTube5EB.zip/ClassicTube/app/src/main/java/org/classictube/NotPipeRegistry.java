package org.classictube;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Fetches and caches notPipe's public instance registry, with a safe empty fallback. */
public final class NotPipeRegistry {
    public static final String FEED_URL = "http://144.31.189.129/notPipe.json";
    private static final String PREFS = "classictube";
    private static final String CACHE_KEY = "notpipe_registry_json";
    private static final String CACHE_TIME_KEY = "notpipe_registry_saved_at";
    private static final long CACHE_MAX_AGE_MS = 6L * 60L * 60L * 1000L;

    public static final class Data {
        public final List<String> invidious = new ArrayList<String>();
        public final List<String> piped = new ArrayList<String>();
        public final List<String> yt2009 = new ArrayList<String>();
        public final List<String> ytApiLegacy = new ArrayList<String>();
    }

    private NotPipeRegistry() {}

    public static Data fetch(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cached = prefs.getString(CACHE_KEY, null);
        long savedAt = prefs.getLong(CACHE_TIME_KEY, 0L);
        long now = System.currentTimeMillis();
        // Reuse a recent registry immediately: the public feed can be slow or unavailable.
        if (cached != null && cached.length() > 0 && now - savedAt >= 0 && now - savedAt < CACHE_MAX_AGE_MS) {
            return parse(cached);
        }
        String json = null;
        try {
            // A very short timeout prevents a dead feed from blocking video search for ages.
            json = HttpJson.get(FEED_URL, 900, 1200);
            if (json != null && json.length() > 0) {
                prefs.edit().putString(CACHE_KEY, json).putLong(CACHE_TIME_KEY, now).commit();
            }
        } catch (Exception ignored) {
            json = cached;
        }
        return parse(json);
    }

    private static Data parse(String json) {
        if (json == null || json.length() == 0) return new Data();
        try {
            Data data = new Data();
            walk(new JSONObject(json), "", data);
            return data;
        } catch (Exception ignored) {
            return new Data();
        }
    }

    private static void walk(Object node, String inheritedType, Data out) {
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            String type = inheritedType;
            String[] typeKeys = new String[] {"type", "api", "provider", "backend", "name"};
            for (int i = 0; i < typeKeys.length; i++) {
                String candidate = inferType(obj.optString(typeKeys[i], ""));
                if (candidate.length() > 0) { type = candidate; break; }
            }
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object value = obj.opt(key);
                String childType = inferType(key);
                if (childType.length() == 0) childType = type;
                if (value instanceof String) {
                    addUrl((String) value, childType, out);
                } else {
                    walk(value, childType, out);
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) walk(arr.opt(i), inheritedType, out);
        } else if (node instanceof String) {
            addUrl((String) node, inheritedType, out);
        }
    }

    private static void addUrl(String value, String type, Data out) {
        if (value == null) return;
        String v = value.trim();
        if (!(v.startsWith("http://") || v.startsWith("https://"))) return;
        String t = inferType(type);
        if (t.length() == 0) return;
        // notPipe's Piped entries may be "API base,proxy base"; ClassicTube needs API base.
        if ("piped".equals(t) && v.indexOf(',') >= 0) v = v.substring(0, v.indexOf(',')).trim();
        v = trim(v);
        List<String> target = listFor(t, out);
        if (target != null && !target.contains(v)) target.add(v);
    }

    private static String inferType(String raw) {
        if (raw == null) return "";
        String s = raw.toLowerCase(Locale.US).replace("_", "").replace("-", "").replace(" ", "");
        if (s.contains("invidious")) return "invidious";
        if (s.contains("ytapilegacy") || s.contains("ytapi") || s.contains("legacy")) return "ytapilegacy";
        if (s.contains("yt2009")) return "yt2009";
        if (s.contains("piped")) return "piped";
        return "";
    }

    private static List<String> listFor(String type, Data out) {
        if ("invidious".equals(type)) return out.invidious;
        if ("piped".equals(type)) return out.piped;
        if ("yt2009".equals(type)) return out.yt2009;
        if ("ytapilegacy".equals(type)) return out.ytApiLegacy;
        return null;
    }

    private static String trim(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
