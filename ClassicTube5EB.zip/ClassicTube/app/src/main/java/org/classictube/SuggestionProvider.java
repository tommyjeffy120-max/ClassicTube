package org.classictube;

import java.util.List;

/** Optional capability implemented only by backends that expose search suggestions. */
public interface SuggestionProvider {
    List<String> suggestions(String query) throws Exception;
}
