package org.classictube;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText query;
    private Button searchButton;
    private TextView status;
    private ListView list;
    private ProgressBar progress;
    private VideoAdapter adapter;
    private final ArrayList<VideoItem> videos = new ArrayList<VideoItem>();
    private final Handler handler = new Handler();
    private volatile boolean searching = false;
    private volatile boolean alive = true;
    private List<Provider> providers;
    private final ArrayList<StreamItem> lastStreams = new ArrayList<StreamItem>();
    private VideoItem selectedVideo;

    private static final String PREFS = "classictube";
    private static final String DEFAULT_INVIDIOUS =
        "https://inv.nadeko.net,https://invidious.nerdvpn.de,https://yt.chocolatemoo53.com,https://invidious.tiekoetter.com";
    private static final String DEFAULT_PIPED =
        "https://pipedapi.kavin.rocks";
    // notPipe's current source defaults to this YtAPILegacy API. It may be offline;
    // the app also attempts to fetch notPipe's current instance registry.
    private static final String DEFAULT_YTAPI = "http://45.132.96.44:2823";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        buildUi();
        providers = buildProviders(new NotPipeRegistry.Data());
        adapter = new VideoAdapter(this, videos);
        list.setAdapter(adapter);
        status.setText("Search videos to begin. Multiple backends enabled; instance list refreshes from notPipe.");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 245, 245));
        root.setPadding(8, 6, 8, 4);

        TextView title = new TextView(this);
        title.setText("ClassicTube");
        title.setTextSize(23);
        title.setTextColor(Color.WHITE);
        title.setPadding(10, 10, 10, 10);
        title.setBackgroundColor(Color.rgb(190, 25, 35));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        query = new EditText(this);
        query.setSingleLine(true);
        query.setTextSize(16);
        query.setHint("Search videos...");
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchRow.addView(query, new LinearLayout.LayoutParams(0, 48, 1));
        searchButton = new Button(this);
        searchButton.setText("Search");
        searchRow.addView(searchButton, new LinearLayout.LayoutParams(-2, 48));
        root.addView(searchRow, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-2, -2));

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(4, 5, 4, 5);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        list = new ListView(this);
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        footer.setText("Home  •  Search  •  History (coming later)");
        footer.setTextSize(12);
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(4, 8, 4, 8);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        searchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doSearch(); }
        });
        query.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    doSearch(); return true;
                }
                return false;
            }
        });
        list.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < videos.size()) showPlaybackOptions(videos.get(position));
            }
        });
    }

    private List<Provider> buildProviders(NotPipeRegistry.Data registry) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String inv = p.getString("invidious", DEFAULT_INVIDIOUS);
        String piped = p.getString("piped", DEFAULT_PIPED);
        ArrayList<Provider> out = new ArrayList<Provider>();

        // Try notPipe's metadata-capable API first; its instance can be replaced by the feed.
        ArrayList<String> yta = new ArrayList<String>();
        if (registry != null) yta.addAll(registry.ytApiLegacy);
        addUnique(yta, DEFAULT_YTAPI);
        for (String b : yta) out.add(new YtApiLegacyProvider(b));

        String[] invs = inv.split(",");
        for (int i = 0; i < invs.length; i++) {
            String b = invs[i].trim();
            if (b.length() > 0) out.add(new InvidiousProvider(b));
        }
        if (registry != null) {
            for (String b : registry.invidious) {
                if (!containsProvider(out, "Invidious", b)) out.add(new InvidiousProvider(b));
            }
        }

        String[] pipes = piped.split(",");
        for (int i = 0; i < pipes.length; i++) {
            String b = pipes[i].trim();
            if (b.length() > 0) out.add(new PipedProvider(b));
        }
        if (registry != null) {
            for (String b : registry.piped) {
                if (!containsProvider(out, "Piped", b)) out.add(new PipedProvider(b));
            }
            for (String b : registry.yt2009) {
                boolean exists = false;
                for (Provider provider : out) {
                    if (provider instanceof Yt2009Provider && ((Yt2009Provider) provider).getBase().equals(b)) { exists = true; break; }
                }
                if (!exists) out.add(new Yt2009Provider(b));
            }
        }
        return out;
    }

    private static void addUnique(List<String> values, String value) {
        if (value != null && value.length() > 0 && !values.contains(value)) values.add(value);
    }

    private static boolean containsProvider(List<Provider> values, String name, String base) {
        String prefix = name + " (" + base + ")";
        for (Provider p : values) {
            // getName is provider type only; the exact base is retained in the instance label below.
            if (p.getName().equals(name)) {
                String baseValue = "";
                if (p instanceof InvidiousProvider) baseValue = ((InvidiousProvider) p).getBase();
                else if (p instanceof PipedProvider) baseValue = ((PipedProvider) p).getBase();
                if (baseValue.equals(base)) return true;
            }
        }
        return false;
    }

    private void doSearch() {
        final String q = query.getText().toString().trim();
        if (q.length() == 0) {
            Toast.makeText(this, "Enter a search term", Toast.LENGTH_SHORT).show();
            return;
        }
        if (searching) return;
        searching = true;
        searchButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Searching providers...");
        videos.clear();
        adapter.notifyDataSetChanged();

        new Thread(new Runnable() {
            public void run() {
                final ArrayList<VideoItem> results = new ArrayList<VideoItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                NotPipeRegistry.Data registry = NotPipeRegistry.fetch(MainActivity.this);
                final List<Provider> searchProviders = buildProviders(registry);
                providers = searchProviders;
                for (Provider p : searchProviders) {
                    try {
                        List<VideoItem> found = p.search(q);
                        for (VideoItem v : found) {
                            boolean duplicate = false;
                            for (VideoItem existing : results) if (existing.id.equals(v.id)) { duplicate = true; break; }
                            if (!duplicate) results.add(v);
                        }
                        if (results.size() >= 15) break;
                    } catch (Exception e) {
                        errors.add(p.getName() + ": " + safeMessage(e));
                    }
                }
                handler.post(new Runnable() {
                    public void run() {
                        searching = false;
                        searchButton.setEnabled(true);
                        progress.setVisibility(View.GONE);
                        videos.clear();
                        videos.addAll(results);
                        adapter.notifyDataSetChanged();
                        if (results.size() > 0) status.setText(results.size() + " results. Tap a video for playback options.");
                        else status.setText("No results. Providers may be offline, blocked, or incompatible. Check your connection and retry.");
                        if (results.size() == 0 && errors.size() > 0) {
                            Toast.makeText(MainActivity.this, "All providers failed (" + errors.size() + ")", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void showPlaybackOptions(final VideoItem video) {
        selectedVideo = video;
        status.setText("Finding available streams for " + video.title + "...");
        progress.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<StreamItem> found = new ArrayList<StreamItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                for (Provider p : providers) {
                    try {
                        List<StreamItem> items = p.streams(video.id);
                        for (StreamItem s : items) {
                            if (HttpJson.isHttpUrl(s.url)) found.add(s);
                        }
                        if (found.size() > 0) break;
                    } catch (Exception e) {
                        errors.add(p.getName());
                    }
                }
                handler.post(new Runnable() {
                    public void run() {
                        progress.setVisibility(View.GONE);
                        if (found.size() == 0) {
                            new AlertDialog.Builder(MainActivity.this)
                                .setTitle("No direct stream available")
                                .setMessage("ClassicTube couldn't obtain a compatible stream from the configured providers. You can try opening the video page in a browser. On Android 2.2, modern TLS and video formats may still prevent playback.")
                                .setPositiveButton("Open video page", new android.content.DialogInterface.OnClickListener() {
                                    public void onClick(android.content.DialogInterface d, int w) { openVideoPage(video); }
                                })
                                .setNegativeButton("Cancel", null).show();
                            status.setText("Direct playback unavailable; browser fallback offered.");
                        } else {
                            Collections.sort(found, new Comparator<StreamItem>() {
                                public int compare(StreamItem a, StreamItem b) { return b.height - a.height; }
                            });
                            showStreamChooser(video, found);
                        }
                    }
                });
            }
        }).start();
    }

    private void showStreamChooser(final VideoItem video, final ArrayList<StreamItem> streams) {
        final ArrayList<StreamItem> choices = new ArrayList<StreamItem>();
        // Prefer combined streams. Provider adapters already filter Piped video-only streams.
        for (StreamItem s : streams) {
            if (s.height <= 360) choices.add(s);
        }
        if (choices.size() == 0) choices.addAll(streams);
        final String[] labels = new String[choices.size() + 1];
        for (int i = 0; i < choices.size(); i++) labels[i] = choices.get(i).label;
        labels[choices.size()] = "Open YouTube video page";
        new AlertDialog.Builder(this).setTitle("Choose quality")
            .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dialog, int which) {
                    if (which == choices.size()) { openVideoPage(video); return; }
                    StreamItem s = choices.get(which);
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.parse(s.url), s.mimeType != null && s.mimeType.length() > 0 ? s.mimeType.split(";")[0] : "video/*");
                        startActivity(intent);
                    } catch (Exception e) {
                        openVideoPage(video);
                    }
                }
            }).show();
        status.setText("Choose an available stream. External player support varies by device.");
    }

    private void openVideoPage(VideoItem v) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + v.id));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No browser is available to open this video.", Toast.LENGTH_LONG).show();
        }
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null ? "request failed" : m;
    }

    private class VideoAdapter extends BaseAdapter {
        private final Context context;
        private final List<VideoItem> items;
        VideoAdapter(Context c, List<VideoItem> list) { context = c; items = list; }
        public int getCount() { return items.size(); }
        public Object getItem(int p) { return items.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int position, View convert, ViewGroup parent) {
            final VideoItem item = items.get(position);
            LinearLayout row;
            ImageView image;
            LinearLayout textCol;
            TextView title;
            TextView meta;
            if (convert instanceof LinearLayout) {
                row = (LinearLayout) convert;
                image = (ImageView) row.getChildAt(0);
                textCol = (LinearLayout) row.getChildAt(1);
                title = (TextView) textCol.getChildAt(0);
                meta = (TextView) textCol.getChildAt(1);
            } else {
                row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(3, 7, 3, 7);
                image = new ImageView(context);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(Color.LTGRAY);
                row.addView(image, new LinearLayout.LayoutParams(112, 72));
                textCol = new LinearLayout(context);
                textCol.setOrientation(LinearLayout.VERTICAL);
                textCol.setPadding(9, 1, 2, 1);
                row.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1));
                title = new TextView(context);
                title.setTextSize(15);
                title.setTextColor(Color.BLACK);
                textCol.addView(title);
                meta = new TextView(context);
                meta.setTextSize(12);
                meta.setTextColor(Color.DKGRAY);
                textCol.addView(meta);
            }
            title.setText(item.title);
            String m = item.author;
            if (item.duration.length() > 0) m += (m.length() > 0 ? " • " : "") + item.duration;
            meta.setText(m);
            image.setImageDrawable(null);
            image.setTag(item.thumbnail);
            if (HttpJson.isHttpUrl(item.thumbnail)) loadThumbnail(image, item.thumbnail);
            return row;
        }
    }

    private void loadThumbnail(final ImageView target, final String address) {
        new Thread(new Runnable() {
            public void run() {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(address).openConnection();
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(5000);
                    c.setRequestProperty("User-Agent", "ClassicTube/0.1");
                    InputStream in = c.getInputStream();
                    BitmapFactory.Options opt = new BitmapFactory.Options();
                    opt.inSampleSize = 2;
                    final Bitmap bmp = BitmapFactory.decodeStream(in, null, opt);
                    in.close();
                    if (bmp != null) handler.post(new Runnable() {
                        public void run() {
                            if (address.equals(target.getTag())) target.setImageBitmap(bmp);
                            else bmp.recycle();
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.disconnect();
                }
            }
        }).start();
    }

    @Override protected void onDestroy() {
        alive = false;
        super.onDestroy();
    }
}
