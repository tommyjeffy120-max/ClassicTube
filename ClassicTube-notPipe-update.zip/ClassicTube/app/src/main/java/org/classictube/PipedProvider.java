package org.classictube;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class PipedProvider implements Provider {
    private final String base;
    public PipedProvider(String base) { this.base = trim(base); }
    public String getName() { return "Piped"; }
    public String getBase() { return base; }

    public List<VideoItem> search(String query) throws Exception {
        String body = HttpJson.get(base + "/search?q=" + HttpJson.enc(query) + "&filter=videos", 4500, 6500);
        JSONArray a;
        if (body.trim().startsWith("[")) {
            a = HttpJson.array(body);
        } else {
            JSONObject searchObject = HttpJson.object(body);
            a = searchObject.optJSONArray("items");
            if (a == null) a = searchObject.optJSONArray("videos");
            if (a == null) a = searchObject.optJSONArray("results");
            if (a == null) throw new Exception("Piped response did not contain a result list");
        }
        List<VideoItem> out = new ArrayList<VideoItem>();
        for (int i = 0; i < a.length() && out.size() < 25; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String url = HttpJson.firstString(o, "url");
            String id = o.optString("id", "");
            if (id.length() == 0 && url.length() > 0) {
                int p = url.lastIndexOf("watch?v=");
                if (p >= 0) {
                id = url.substring(p + 8);
                int amp = id.indexOf('&');
                if (amp >= 0) id = id.substring(0, amp);
            }
            }
            if (id.length() == 0) continue;
            VideoItem v = new VideoItem();
            v.id = id;
            v.title = o.optString("title", "Untitled");
            v.author = HttpJson.firstString(o, "uploaderName", "uploader", "channel");
            v.duration = duration(o.optLong("duration", 0));
            v.thumbnail = HttpJson.firstString(o, "thumbnail", "thumbnailUrl");
            v.provider = getName() + " (" + base + ")";
            out.add(v);
        }
        if (out.size() == 0) throw new Exception("No video results");
        return out;
    }

    public List<StreamItem> streams(String videoId) throws Exception {
        JSONObject o = HttpJson.object(HttpJson.get(base + "/streams/" + HttpJson.enc(videoId)));
        JSONArray a = o.optJSONArray("videoStreams");
        List<StreamItem> out = new ArrayList<StreamItem>();
        if (a != null) for (int i = 0; i < a.length(); i++) {
            JSONObject f = a.optJSONObject(i);
            if (f == null || f.optBoolean("videoOnly", false)) continue;
            String url = f.optString("url", "");
            if (url.length() == 0) continue;
            String q = HttpJson.firstString(f, "quality", "resolution");
            String mime = HttpJson.firstString(f, "mimeType", "format");
            int h = parseHeight(q);
            out.add(new StreamItem((q.length() > 0 ? q : "Video stream") + (mime.length() > 0 ? " · " + mime.split(";")[0] : ""), url, mime, h));
        }
        if (out.size() == 0) throw new Exception("This instance returned no compatible combined streams");
        return out;
    }

    private static int parseHeight(String q) {
        if (q == null) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3,4})p").matcher(q);
        if (m.find()) try { return Integer.parseInt(m.group(1)); } catch (Exception e) {}
        return 0;
    }
    private static String duration(long s) {
        if (s <= 0) return "";
        return String.format("%d:%02d", s / 60, s % 60);
    }
    private static String trim(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
