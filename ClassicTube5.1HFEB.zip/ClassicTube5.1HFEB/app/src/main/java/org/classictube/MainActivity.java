package org.classictube;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText query;
    private Button searchButton;
    private LinearLayout suggestionsBox;
    private TextView status;
    private ListView list;
    private ProgressBar progress;
    private VideoAdapter adapter;
    private final ArrayList<VideoItem> videos = new ArrayList<VideoItem>();
    private final Handler handler = new Handler();
    private Runnable pendingSuggestion;
    private volatile int suggestionGeneration = 0;
    private volatile boolean searching = false;
    private volatile boolean alive = true;
    private List<Provider> providers;
    private final ArrayList<StreamItem> lastStreams = new ArrayList<StreamItem>();
    private VideoItem selectedVideo;

    private static final String PREFS = "classictube";
    private static final String DEFAULT_INVIDIOUS =
        "https://inv.nadeko.net,https://invidious.nerdvpn.de,https://yt.chocolatemoo53.com,https://invidious.tiekoetter.com,https://invidious.f5.si";
    // Snapshot of instances on the projects' published lists at the time of this build.
    // Community-operated servers can still be unavailable, rate-limited, or change APIs.
    private static final String DEFAULT_PIPED =
        "https://pipedapi.kavin.rocks,https://pipedapi.leptons.xyz,https://pipedapi.nosebs.ru,https://pipedapi-libre.kavin.rocks,https://piped-api.privacy.com.de,https://pipedapi.adminforge.de,https://api.piped.yt,https://pipedapi.drgns.space,https://pipedapi.owo.si,https://pipedapi.ducks.party,https://piped-api.codespace.cz,https://pipedapi.reallyaweso.me,https://api.piped.private.coffee,https://pipedapi.darkness.services,https://pipedapi.orangenet.cc";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        buildUi();
        providers = buildProviders(new NotPipeRegistry.Data());
        adapter = new VideoAdapter(this, videos);
        list.setAdapter(adapter);
        status.setText("Search videos to begin. Multiple backends enabled; instance list refreshes from notPipe.");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 245, 245));
        root.setPadding(8, 6, 8, 4);

        TextView title = new TextView(this);
        title.setText("ClassicTube");
        title.setTextSize(23);
        title.setTextColor(Color.WHITE);
        title.setPadding(10, 10, 10, 10);
        title.setBackgroundColor(Color.rgb(190, 25, 35));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        query = new EditText(this);
        query.setSingleLine(true);
        query.setTextSize(16);
        query.setHint("Search videos...");
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchRow.addView(query, new LinearLayout.LayoutParams(0, 48, 1));
        searchButton = new Button(this);
        searchButton.setText("Search");
        searchRow.addView(searchButton, new LinearLayout.LayoutParams(-2, 48));
        root.addView(searchRow, new LinearLayout.LayoutParams(-1, -2));

        suggestionsBox = new LinearLayout(this);
        suggestionsBox.setOrientation(LinearLayout.VERTICAL);
        suggestionsBox.setPadding(4, 0, 4, 2);
        suggestionsBox.setBackgroundColor(Color.WHITE);
        suggestionsBox.setVisibility(View.GONE);
        root.addView(suggestionsBox, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-2, -2));

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(4, 5, 4, 5);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        list = new ListView(this);
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        String version = BuildConfig.VERSION_NAME;
        if (version.endsWith("-alpha")) version = version.substring(0, version.length() - 6) + " Alpha";
        footer.setText("ClassicTube " + version);
        footer.setTextSize(11);
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(4, 7, 4, 6);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        searchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doSearch(); }
        });
        query.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    doSearch(); return true;
                }
                return false;
            }
        });
        query.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                scheduleSuggestions(s == null ? "" : s.toString().trim());
            }
            public void afterTextChanged(Editable e) {}
        });
        list.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < videos.size()) showPlaybackOptions(videos.get(position));
            }
        });
    }

    private void scheduleSuggestions(final String text) {
        if (pendingSuggestion != null) handler.removeCallbacks(pendingSuggestion);
        final int generation = ++suggestionGeneration;
        hideSuggestions();
        if (searching || text.length() < 2 || !alive) return;
        pendingSuggestion = new Runnable() {
            public void run() { fetchSuggestions(text, generation); }
        };
        handler.postDelayed(pendingSuggestion, 420L);
    }

    private void hideSuggestions() {
        if (suggestionsBox != null) {
            suggestionsBox.removeAllViews();
            suggestionsBox.setVisibility(View.GONE);
        }
    }

    private void cancelSuggestions() {
        suggestionGeneration++;
        if (pendingSuggestion != null) handler.removeCallbacks(pendingSuggestion);
        pendingSuggestion = null;
        hideSuggestions();
    }

    private void fetchSuggestions(final String text, final int generation) {
        if (providers == null || text.length() < 2) return;
        final ArrayList<SuggestionProvider> candidates = new ArrayList<SuggestionProvider>();
        int invidiousCount = 0;
        int pipedCount = 0;
        for (Provider provider : providers) {
            if (!(provider instanceof SuggestionProvider)) continue;
            if (provider instanceof InvidiousProvider && invidiousCount < 2) {
                candidates.add((SuggestionProvider) provider);
                invidiousCount++;
            } else if (provider instanceof PipedProvider && pipedCount < 2) {
                candidates.add((SuggestionProvider) provider);
                pipedCount++;
            }
        }
        if (candidates.size() == 0) return;
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<String> merged = new ArrayList<String>();
                ExecutorService executor = Executors.newFixedThreadPool(Math.min(4, candidates.size()));
                CompletionService<List<String>> completion = new ExecutorCompletionService<List<String>>(executor);
                ArrayList<Future<List<String>>> futures = new ArrayList<Future<List<String>>>();
                for (final SuggestionProvider provider : candidates) {
                    futures.add(completion.submit(new Callable<List<String>>() {
                        public List<String> call() throws Exception { return provider.suggestions(text); }
                    }));
                }
                long deadline = System.currentTimeMillis() + 2300L;
                int completed = 0;
                try {
                    while (completed < futures.size() && merged.size() < 6) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (remaining <= 0) break;
                        Future<List<String>> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        try {
                            List<String> items = future.get();
                            if (items != null) {
                                for (String item : items) {
                                    String clean = item == null ? "" : item.trim();
                                    if (clean.length() > 0 && !clean.equalsIgnoreCase(text) && !merged.contains(clean)) merged.add(clean);
                                    if (merged.size() >= 6) break;
                                }
                            }
                        } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {
                } finally {
                    for (Future<List<String>> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                handler.post(new Runnable() {
                    public void run() {
                        if (!alive || generation != suggestionGeneration || searching) return;
                        if (!text.equals(query.getText().toString().trim())) return;
                        showSuggestions(merged);
                    }
                });
            }
        }).start();
    }

    private void showSuggestions(List<String> values) {
        hideSuggestions();
        if (values == null || values.size() == 0 || searching) return;
        TextView heading = new TextView(this);
        heading.setText("Search suggestions");
        heading.setTextSize(11);
        heading.setTextColor(Color.GRAY);
        heading.setPadding(8, 5, 8, 3);
        suggestionsBox.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        for (final String value : values) {
            TextView row = new TextView(this);
            row.setText("⌕  " + value);
            row.setTextSize(14);
            row.setTextColor(Color.DKGRAY);
            row.setPadding(10, 8, 10, 8);
            row.setBackgroundColor(Color.WHITE);
            row.setClickable(true);
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    query.setText(value);
                    query.setSelection(query.length());
                    cancelSuggestions();
                    doSearch();
                }
            });
            suggestionsBox.addView(row, new LinearLayout.LayoutParams(-1, -2));
            View divider = new View(this);
            divider.setBackgroundColor(Color.rgb(232, 232, 232));
            suggestionsBox.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        }
        suggestionsBox.setVisibility(View.VISIBLE);
    }

    private List<Provider> buildProviders(NotPipeRegistry.Data registry) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String inv = p.getString("invidious", DEFAULT_INVIDIOUS);
        String piped = p.getString("piped", DEFAULT_PIPED);
        ArrayList<Provider> out = new ArrayList<Provider>();

        // Use YtAPILegacy only when a live registry supplies an instance. The old
        // hard-coded IP fallback has been refusing connections and made every search
        // report a guaranteed provider failure when the registry was unavailable.
        ArrayList<String> yta = new ArrayList<String>();
        if (registry != null) yta.addAll(registry.ytApiLegacy);
        for (String b : yta) out.add(new YtApiLegacyProvider(b));

        String[] invs = inv.split(",");
        for (int i = 0; i < invs.length; i++) {
            String b = invs[i].trim();
            if (b.length() > 0) out.add(new InvidiousProvider(b));
        }
        if (registry != null) {
            for (String b : registry.invidious) {
                if (!containsProvider(out, "Invidious", b)) out.add(new InvidiousProvider(b));
            }
        }

        String[] pipes = piped.split(",");
        for (int i = 0; i < pipes.length; i++) {
            String b = pipes[i].trim();
            if (b.length() > 0) out.add(new PipedProvider(b));
        }
        if (registry != null) {
            for (String b : registry.piped) {
                if (!containsProvider(out, "Piped", b)) out.add(new PipedProvider(b));
            }
            for (String b : registry.yt2009) {
                boolean exists = false;
                for (Provider provider : out) {
                    if (provider instanceof Yt2009Provider && ((Yt2009Provider) provider).getBase().equals(b)) { exists = true; break; }
                }
                if (!exists) out.add(new Yt2009Provider(b));
            }
        }
        return out;
    }

    private static void addUnique(List<String> values, String value) {
        if (value != null && value.length() > 0 && !values.contains(value)) values.add(value);
    }

    private static boolean containsProvider(List<Provider> values, String name, String base) {
        String prefix = name + " (" + base + ")";
        for (Provider p : values) {
            // getName is provider type only; the exact base is retained in the instance label below.
            if (p.getName().equals(name)) {
                String baseValue = "";
                if (p instanceof InvidiousProvider) baseValue = ((InvidiousProvider) p).getBase();
                else if (p instanceof PipedProvider) baseValue = ((PipedProvider) p).getBase();
                if (baseValue.equals(base)) return true;
            }
        }
        return false;
    }

    private void doSearch() {
        final String q = query.getText().toString().trim();
        if (q.length() == 0) {
            Toast.makeText(this, "Enter a search term", Toast.LENGTH_SHORT).show();
            return;
        }
        if (searching) return;
        cancelSuggestions();
        searching = true;
        searchButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Searching available providers...");
        videos.clear();
        adapter.notifyDataSetChanged();

        new Thread(new Runnable() {
            public void run() {
                final ArrayList<VideoItem> results = new ArrayList<VideoItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                NotPipeRegistry.Data registry = NotPipeRegistry.fetch(MainActivity.this);
                final List<Provider> allProviders = buildProviders(registry);
                providers = allProviders;
                final List<Provider> searchList = chooseSearchProviders(allProviders);
                ExecutorService executor = Executors.newFixedThreadPool(4);
                CompletionService<SearchOutcome> completion = new ExecutorCompletionService<SearchOutcome>(executor);
                ArrayList<Future<SearchOutcome>> futures = new ArrayList<Future<SearchOutcome>>();
                for (final Provider provider : searchList) {
                    futures.add(completion.submit(new Callable<SearchOutcome>() {
                        public SearchOutcome call() {
                            SearchOutcome outcome = new SearchOutcome();
                            outcome.provider = provider.getName();
                            try { outcome.items = provider.search(q); }
                            catch (Exception e) { outcome.error = providerLabel(provider) + ": " + safeMessage(e); }
                            return outcome;
                        }
                    }));
                }
                long deadline = System.currentTimeMillis() + 9500L;
                int completed = 0;
                try {
                    while (completed < futures.size() && results.size() < 10) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (remaining <= 0) break;
                        Future<SearchOutcome> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        SearchOutcome outcome = future.get();
                        if (outcome.error != null) errors.add(outcome.error);
                        if (outcome.items != null) {
                            for (VideoItem v : outcome.items) {
                                boolean duplicate = false;
                                for (VideoItem existing : results) {
                                    if (existing.id.equals(v.id)) { duplicate = true; break; }
                                }
                                if (!duplicate) results.add(v);
                                if (results.size() >= 15) break;
                            }
                        }
                    }
                } catch (Exception e) {
                    errors.add("Search: " + safeMessage(e));
                } finally {
                    for (Future<SearchOutcome> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                handler.post(new Runnable() {
                    public void run() {
                        searching = false;
                        searchButton.setEnabled(true);
                        progress.setVisibility(View.GONE);
                        videos.clear();
                        videos.addAll(results);
                        adapter.notifyDataSetChanged();
                        if (results.size() > 0) status.setText(results.size() + " results. Tap a video for playback options.");
                        else status.setText("No results. Providers may be offline, blocked, or incompatible. Check your connection and retry.");
                        if (results.size() == 0 && errors.size() > 0) {
                            StringBuilder details = new StringBuilder();
                            int shown = Math.min(4, errors.size());
                            for (int i = 0; i < shown; i++) {
                                if (i > 0) details.append("\n");
                                details.append(errors.get(i));
                            }
                            status.setText("Search failed on " + errors.size() + " provider(s). First errors:\n" + details.toString());
                            Toast.makeText(MainActivity.this, "Search failed on " + errors.size() + " providers. See details on screen.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    /** Select a small, balanced set so one provider family cannot make search crawl. */
    private List<Provider> chooseSearchProviders(List<Provider> all) {
        ArrayList<Provider> selected = new ArrayList<Provider>();
        String[] types = new String[] {"YtAPILegacy", "Invidious", "Piped"};
        int[] limits = new int[] {2, 3, 3};
        for (int round = 0; round < 3; round++) {
            for (int t = 0; t < types.length; t++) {
                int found = 0;
                for (Provider p : all) {
                    if (p.getName().equals("yt2009")) continue;
                    if (!p.getName().equals(types[t])) continue;
                    found++;
                    if (found == round + 1 && round < limits[t]) {
                        selected.add(p);
                        break;
                    }
                }
            }
        }
        if (selected.size() == 0) {
            for (Provider p : all) if (!p.getName().equals("yt2009")) selected.add(p);
        }
        return selected;
    }

    private static String providerLabel(Provider provider) {
        String base = "";
        if (provider instanceof InvidiousProvider) base = ((InvidiousProvider) provider).getBase();
        else if (provider instanceof PipedProvider) base = ((PipedProvider) provider).getBase();
        else if (provider instanceof Yt2009Provider) base = ((Yt2009Provider) provider).getBase();
        else if (provider instanceof YtApiLegacyProvider) base = ((YtApiLegacyProvider) provider).getBase();
        if (base.length() == 0) return provider.getName();
        try { return provider.getName() + " [" + new URL(base).getHost() + "]"; }
        catch (Exception ignored) { return provider.getName() + " [" + base + "]"; }
    }

    private static class SearchOutcome {
        List<VideoItem> items;
        String error;
        String provider;
    }

    private void showPlaybackOptions(final VideoItem video) {
        selectedVideo = video;
        status.setText("Finding a playable stream...");
        progress.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<StreamItem> found = new ArrayList<StreamItem>();
                final ArrayList<String> errors = new ArrayList<String>();
                final List<Provider> candidates = choosePlaybackProviders(providers);
                ExecutorService executor = Executors.newFixedThreadPool(4);
                CompletionService<StreamOutcome> completion = new ExecutorCompletionService<StreamOutcome>(executor);
                ArrayList<Future<StreamOutcome>> futures = new ArrayList<Future<StreamOutcome>>();
                for (final Provider provider : candidates) {
                    futures.add(completion.submit(new Callable<StreamOutcome>() {
                        public StreamOutcome call() {
                            StreamOutcome outcome = new StreamOutcome();
                            outcome.provider = provider.getName();
                            try { outcome.items = provider.streams(video.id); }
                            catch (Exception e) { outcome.error = providerLabel(provider) + ": " + safeMessage(e); }
                            return outcome;
                        }
                    }));
                }
                long deadline = System.currentTimeMillis() + 8000L;
                int completed = 0;
                int successfulBackends = 0;
                try {
                    while (completed < futures.size()) {
                        long remaining = deadline - System.currentTimeMillis();
                        if (remaining <= 0) break;
                        Future<StreamOutcome> future = completion.poll(remaining, TimeUnit.MILLISECONDS);
                        if (future == null) break;
                        completed++;
                        StreamOutcome outcome = future.get();
                        if (outcome.error != null) errors.add(outcome.error);
                        if (outcome.items != null && outcome.items.size() > 0) {
                            successfulBackends++;
                            for (StreamItem stream : outcome.items) {
                                if (HttpJson.isHttpUrl(stream.url)) {
                                    String label = stream.label == null ? "Available stream" : stream.label;
                                    found.add(new StreamItem(outcome.provider + " · " + label, stream.url, stream.mimeType, stream.height));
                                }
                            }
                        }
                        // One provider gives us an initial option quickly; wait briefly for a fallback source.
                        if (successfulBackends >= 2 && found.size() >= 2) break;
                        if (successfulBackends >= 1 && completed >= futures.size()) break;
                    }
                } catch (Exception e) {
                    errors.add("Playback: " + safeMessage(e));
                } finally {
                    for (Future<StreamOutcome> future : futures) future.cancel(true);
                    executor.shutdownNow();
                }
                handler.post(new Runnable() {
                    public void run() {
                        progress.setVisibility(View.GONE);
                        if (found.size() == 0) {
                            new AlertDialog.Builder(MainActivity.this)
                                .setTitle("No direct stream available")
                                .setMessage("The available providers did not return a stream quickly enough. This may be a dead instance, an expired link, or a format unsupported by this device. Try another video or retry later.")
                                .setPositiveButton("Open video page", new android.content.DialogInterface.OnClickListener() {
                                    public void onClick(android.content.DialogInterface d, int w) { openVideoPage(video); }
                                })
                                .setNegativeButton("Cancel", null).show();
                            status.setText("No playable stream found. Try another provider or video.");
                        } else {
                            Collections.sort(found, new Comparator<StreamItem>() {
                                public int compare(StreamItem a, StreamItem b) { return b.height - a.height; }
                            });
                            showStreamChooser(video, found);
                        }
                    }
                });
            }
        }).start();
    }

    private List<Provider> choosePlaybackProviders(List<Provider> all) {
        ArrayList<Provider> selected = new ArrayList<Provider>();
        if (all == null) return selected;
        String[] types = new String[] {"Invidious", "Piped", "YtAPILegacy", "yt2009"};
        int[] limits = new int[] {2, 2, 1, 1};
        for (int round = 0; round < 2; round++) {
            for (int t = 0; t < types.length; t++) {
                if (round >= limits[t]) continue;
                int foundCount = 0;
                for (Provider p : all) {
                    if (!p.getName().equals(types[t])) continue;
                    foundCount++;
                    if (foundCount == round + 1) { selected.add(p); break; }
                }
            }
        }
        return selected;
    }

    private static class StreamOutcome {
        List<StreamItem> items;
        String error;
        String provider;
    }

    private void showStreamChooser(final VideoItem video, final ArrayList<StreamItem> streams) {
        final ArrayList<StreamItem> choices = new ArrayList<StreamItem>(streams);
        // Put 360p first when offered; otherwise prefer the closest lower quality before higher ones.
        // Keep all returned qualities available so users can choose 480p, 720p, or higher if supported.
        Collections.sort(choices, new Comparator<StreamItem>() {
            public int compare(StreamItem a, StreamItem b) {
                int ah = a.height > 0 ? Math.abs(a.height - 360) : 10000;
                int bh = b.height > 0 ? Math.abs(b.height - 360) : 10000;
                if (ah != bh) return ah - bh;
                if (a.height != b.height) return a.height - b.height;
                return String.valueOf(a.label).compareToIgnoreCase(String.valueOf(b.label));
            }
        });
        final String[] labels = new String[choices.size() + 1];
        final String[] urls = new String[choices.size()];
        final String[] mimes = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            labels[i] = choices.get(i).label;
            if (i == 0 && choices.get(i).height == 360) labels[i] = "Recommended · " + labels[i];
            urls[i] = choices.get(i).url;
            mimes[i] = choices.get(i).mimeType == null ? "video/*" : choices.get(i).mimeType;
        }
        labels[choices.size()] = "Open YouTube video page";
        new AlertDialog.Builder(this).setTitle("Choose quality / source")
            .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                public void onClick(android.content.DialogInterface dialog, int which) {
                    if (which == choices.size()) { openVideoPage(video); return; }
                    StreamItem stream = choices.get(which);
                    Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                    intent.putExtra(PlayerActivity.EXTRA_TITLE, video.title);
                    intent.putExtra(PlayerActivity.EXTRA_VIDEO_ID, video.id);
                    intent.putExtra(PlayerActivity.EXTRA_URLS, urls);
                    intent.putExtra(PlayerActivity.EXTRA_LABELS, labelsForChoices(choices));
                    intent.putExtra(PlayerActivity.EXTRA_MIMES, mimes);
                    intent.putExtra(PlayerActivity.EXTRA_START_INDEX, which);
                    intent.putExtra(PlayerActivity.EXTRA_URL, stream.url);
                    intent.putExtra(PlayerActivity.EXTRA_MIME, stream.mimeType == null ? "video/*" : stream.mimeType);
                    intent.putExtra(PlayerActivity.EXTRA_LABEL, stream.label == null ? "Video" : stream.label);
                    startActivity(intent);
                }
            }).show();
        status.setText("Choose a quality. Playback stays inside ClassicTube.");
    }

    private String[] labelsForChoices(ArrayList<StreamItem> choices) {
        String[] out = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) out[i] = choices.get(i).label == null ? "Video stream" : choices.get(i).label;
        return out;
    }

    private void openVideoPage(VideoItem v) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + v.id));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No browser is available to open this video.", Toast.LENGTH_LONG).show();
        }
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null ? "request failed" : m;
    }

    private class VideoAdapter extends BaseAdapter {
        private final Context context;
        private final List<VideoItem> items;
        VideoAdapter(Context c, List<VideoItem> list) { context = c; items = list; }
        public int getCount() { return items.size(); }
        public Object getItem(int p) { return items.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int position, View convert, ViewGroup parent) {
            final VideoItem item = items.get(position);
            LinearLayout row;
            ImageView image;
            LinearLayout textCol;
            TextView title;
            TextView meta;
            if (convert instanceof LinearLayout) {
                row = (LinearLayout) convert;
                image = (ImageView) row.getChildAt(0);
                textCol = (LinearLayout) row.getChildAt(1);
                title = (TextView) textCol.getChildAt(0);
                meta = (TextView) textCol.getChildAt(1);
            } else {
                row = new LinearLayout(context);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(3, 7, 3, 7);
                image = new ImageView(context);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(Color.LTGRAY);
                row.addView(image, new LinearLayout.LayoutParams(112, 72));
                textCol = new LinearLayout(context);
                textCol.setOrientation(LinearLayout.VERTICAL);
                textCol.setPadding(9, 1, 2, 1);
                row.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1));
                title = new TextView(context);
                title.setTextSize(15);
                title.setTextColor(Color.BLACK);
                textCol.addView(title);
                meta = new TextView(context);
                meta.setTextSize(12);
                meta.setTextColor(Color.DKGRAY);
                textCol.addView(meta);
            }
            title.setText(item.title);
            String m = item.author;
            if (item.duration.length() > 0) m += (m.length() > 0 ? " • " : "") + item.duration;
            meta.setText(m);
            image.setImageDrawable(null);
            image.setTag("video:" + item.id);
            loadThumbnail(image, item.thumbnail, item.id);
            return row;
        }
    }

    private void loadThumbnail(final ImageView target, final String address, final String videoId) {
        final String expectedTag = "video:" + videoId;
        new Thread(new Runnable() {
            public void run() {
                Bitmap bmp = null;
                String[] candidates = new String[] {
                    address,
                    "https://i.ytimg.com/vi/" + videoId + "/mqdefault.jpg",
                    "https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg"
                };
                for (int i = 0; i < candidates.length && bmp == null; i++) {
                    String candidate = candidates[i];
                    if (!HttpJson.isHttpUrl(candidate)) continue;
                    boolean seen = false;
                    for (int j = 0; j < i; j++) if (candidate.equals(candidates[j])) seen = true;
                    if (seen) continue;
                    HttpURLConnection c = null;
                    InputStream in = null;
                    try {
                        c = (HttpURLConnection) new URL(candidate).openConnection();
                        c.setConnectTimeout(2200);
                        c.setReadTimeout(2800);
                        c.setInstanceFollowRedirects(true);
                        c.setRequestProperty("User-Agent", "ClassicTube/0.3 (Android video client)");
                        c.setRequestProperty("Accept", "image/*,*/*;q=0.8");
                        int code = c.getResponseCode();
                        if (code < 200 || code >= 300) continue;
                        in = c.getInputStream();
                        BitmapFactory.Options opt = new BitmapFactory.Options();
                        opt.inSampleSize = 2;
                        bmp = BitmapFactory.decodeStream(in, null, opt);
                    } catch (Exception ignored) {
                    } finally {
                        try { if (in != null) in.close(); } catch (Exception ignored) {}
                        if (c != null) c.disconnect();
                    }
                }
                final Bitmap finalBitmap = bmp;
                if (finalBitmap != null) handler.post(new Runnable() {
                    public void run() {
                        if (expectedTag.equals(target.getTag())) target.setImageBitmap(finalBitmap);
                        else finalBitmap.recycle();
                    }
                });
            }
        }).start();
    }

    @Override protected void onDestroy() {
        alive = false;
        super.onDestroy();
    }
}
