# ClassicTube 0.0.5 Alpha — provider failover hotfix (internal version code 7)

A lightweight native Java Android client targeting Android 2.2 (API 8). This release builds on the 0.0.4 fullscreen player and multi-provider adapters.

## What's new in 0.0.5 Alpha

- Debounced live search suggestions from compatible Invidious and Piped instances. The suggestion panel is optional: normal search continues to work if suggestions are unavailable.
- Suggestions are queried in parallel across a small sample of instances, merged, deduplicated, and capped to six so typing remains responsive.
- A simple footer now displays `ClassicTube 0.0.5 Alpha`; the displayed version is derived from the Android app version configuration.
- The default Piped pool prioritizes alternate published community instances before the hosts reported failing in recent tests. Search now tries instances beyond the first three, up to its bounded fallback window; community servers remain best-effort and may be offline or incompatible at any time.
- Invidious instances are added dynamically only when the maintained instances feed marks their API as enabled and the endpoint is HTTPS. A known API-enabled HTTPS instance remains as the offline fallback. The separate notPipe registry is no longer allowed to add Invidious servers that the maintained feed marks as API-disabled.
- Search now interleaves provider types, tries the full available instance list with bounded concurrency, and allows a longer fallback window. A provider that returns results is promoted for the next search.
- If a search returns no results, the screen displays provider-specific errors and hostnames, plus how many provider responses completed before the fallback time limit. This distinguishes DNS/network failures, HTTP errors, and response-format/API errors without relying on a generic toast.
- Removed the fixed YtAPILegacy IP fallback after it repeatedly refused connections; YtAPILegacy is added only when the notPipe registry provides an instance.
- Quality selection retains every stream returned by the selected providers and places 360p first when available. Lower/higher qualities remain selectable.
- Preserves the built-in VideoView player, fullscreen toggle, seek bar/time controls supplied by Android's MediaController, retry, next-source, and external-player fallback.

## Known limitations

- This is an alpha prototype. Public instances can go offline, block requests, change APIs, or provide streams unsupported by the device.
- Suggestion endpoints differ by backend and may not be available on every instance. A failed suggestion request does not block ordinary search.
- The yt2009 adapter is playback-only here; it is not used to search.
- Android 2.2's old TLS support can reject modern HTTPS servers. The app does not disable TLS certificate verification.
- Invidious' maintained public list is currently short; avoid treating a server from an arbitrary list as trusted. Piped instance URLs are community-operated and not guaranteed to work.

## References

- Invidious API, including `/api/v1/search/suggestions`: https://docs.invidious.io/api/
- Invidious maintained public instance list: https://docs.invidious.io/instances/
- Piped API, including `/suggestions`: https://docs.piped.video/docs/api-documentation/
- Piped community instance list: https://github.com/TeamPiped/Piped/wiki/Instances
- notPipe source and backend adapters: https://github.com/gohoski/notPipe
- notPipe instance feed referenced by the existing adapter: http://144.31.189.129/notPipe.json

## Build

The source zip does not include an APK. In the existing GitHub Actions workflow, replace the ZIP currently named `ClassicTube Fullscreen Upd.zip` in the repository root with this archive (keeping that filename), then run the workflow. The workflow and repository configuration are kept separate from this source project.
